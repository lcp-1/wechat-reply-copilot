from enum import IntFlag

import comtypes.gen._1EA4DBF0_3C3B_11CF_810C_00AA00389B71_0_1_1 as __wrapper_module__
from comtypes.gen._1EA4DBF0_3C3B_11CF_810C_00AA00389B71_0_1_1 import (
    ANNO_THIS, HRESULT, ANNO_CONTAINER, wireHMENU, COMMETHOD,
    typelib_path, _RemotableHandle, IAccPropServer, IAccPropServices,
    IAccessible, wireHWND, BSTR, dispid, __MIDL_IWinTypes_0009,
    Library, VARIANT, WSTRING, _lcid, CoClass, IAccIdentity,
    _check_version, IAccessibleHandler, GUID, CAccPropServices,
    IDispatch
)


class AnnoScope(IntFlag):
    ANNO_THIS = 0
    ANNO_CONTAINER = 1


__all__ = [
    'ANNO_THIS', 'ANNO_CONTAINER', 'AnnoScope', 'wireHMENU',
    'typelib_path', 'Library', '__MIDL_IWinTypes_0009',
    'CAccPropServices', '_RemotableHandle', 'IAccPropServer',
    'IAccIdentity', 'IAccessibleHandler', 'IAccPropServices',
    'IAccessible'
]

