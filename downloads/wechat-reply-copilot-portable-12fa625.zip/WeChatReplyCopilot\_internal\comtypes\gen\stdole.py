from enum import IntFlag

import comtypes.gen._00020430_0000_0000_C000_000000000046_0_2_0 as __wrapper_module__
from comtypes.gen._00020430_0000_0000_C000_000000000046_0_2_0 import (
    IFontEventsDisp, FONTSTRIKETHROUGH, OLE_CANCELBOOL, FONTBOLD,
    OLE_OPTEXCLUSIVE, IPicture, OLE_XSIZE_HIMETRIC, _lcid,
    OLE_XSIZE_PIXELS, dispid, BSTR, Default, Checked, IDispatch,
    OLE_XPOS_PIXELS, StdFont, OLE_XPOS_CONTAINER, FONTNAME, IFont,
    OLE_XPOS_HIMETRIC, OLE_ENABLEDEFAULTBOOL, Monochrome, HRESULT,
    typelib_path, IUnknown, FONTSIZE, CoClass, OLE_YPOS_CONTAINER,
    Font, Unchecked, DISPPARAMS, IEnumVARIANT, VgaColor,
    _check_version, OLE_YSIZE_CONTAINER, IPictureDisp,
    OLE_XSIZE_CONTAINER, Library, IFontDisp, Picture, Gray,
    DISPPROPERTY, OLE_YSIZE_PIXELS, OLE_YPOS_HIMETRIC, COMMETHOD,
    EXCEPINFO, Color, FONTUNDERSCORE, VARIANT_BOOL, StdPicture,
    OLE_HANDLE, GUID, DISPMETHOD, OLE_COLOR, OLE_YPOS_PIXELS,
    FONTITALIC, OLE_YSIZE_HIMETRIC, FontEvents
)


class LoadPictureConstants(IntFlag):
    Default = 0
    Monochrome = 1
    VgaColor = 2
    Color = 4


class OLE_TRISTATE(IntFlag):
    Unchecked = 0
    Checked = 1
    Gray = 2


__all__ = [
    'Unchecked', 'IFontEventsDisp', 'VgaColor', 'FONTSTRIKETHROUGH',
    'OLE_YSIZE_CONTAINER', 'OLE_CANCELBOOL', 'FONTBOLD',
    'OLE_OPTEXCLUSIVE', 'IPicture', 'IPictureDisp',
    'OLE_XSIZE_CONTAINER', 'OLE_XSIZE_HIMETRIC', 'OLE_TRISTATE',
    'Library', 'IFontDisp', 'OLE_XSIZE_PIXELS', 'Default', 'Picture',
    'FontEvents', 'Gray', 'Checked', 'OLE_XPOS_PIXELS', 'StdFont',
    'OLE_YSIZE_PIXELS', 'LoadPictureConstants', 'OLE_XPOS_CONTAINER',
    'OLE_YPOS_HIMETRIC', 'FONTNAME', 'IFont', 'OLE_XPOS_HIMETRIC',
    'OLE_ENABLEDEFAULTBOOL', 'Monochrome', 'Color', 'FONTUNDERSCORE',
    'typelib_path', 'OLE_HANDLE', 'StdPicture', 'FONTSIZE',
    'OLE_COLOR', 'OLE_YPOS_PIXELS', 'FONTITALIC',
    'OLE_YPOS_CONTAINER', 'OLE_YSIZE_HIMETRIC', 'Font'
]

