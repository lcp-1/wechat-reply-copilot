from enum import IntFlag

import comtypes.gen._944DE083_8FB8_45CF_BCB7_C477ACB2F897_0_1_0 as __wrapper_module__
from comtypes.gen._944DE083_8FB8_45CF_BCB7_C477ACB2F897_0_1_0 import (
    Polite, UIA_EditControlTypeId, AnnotationType_Footer,
    UIA_AnnotationTargetPropertyId, AnnotationType_ConflictingChange,
    IUIAutomationCondition, UIA_DragIsGrabbedPropertyId,
    TextUnit_Character, ZoomUnit_NoAmount, IUIAutomationElement9,
    UIA_ScrollHorizontalScrollPercentPropertyId,
    ToggleState_Indeterminate,
    UIA_IsTransformPattern2AvailablePropertyId,
    ConnectionRecoveryBehaviorOptions_Disabled,
    UIA_ImageControlTypeId, UIA_CapStyleAttributeId,
    UIA_IsDialogPropertyId, UIA_ComboBoxControlTypeId,
    UIA_HeaderItemControlTypeId, UIA_Window_WindowClosedEventId,
    UIA_Transform2CanZoomPropertyId, UIA_VirtualizedItemPatternId,
    IUIAutomation, StructureChangeType_ChildAdded,
    IUIAutomationActiveTextPositionChangedEventHandler,
    UIA_ControllerForPropertyId, UIA_StrikethroughStyleAttributeId,
    UIA_StrikethroughColorAttributeId,
    StructureChangeType_ChildrenBulkRemoved, IUIAutomationDockPattern,
    ToggleState_On, IUIAutomationGridItemPattern, HeadingLevel6,
    ExtendedProperty, CUIAutomation8, UIA_IsActiveAttributeId,
    ScrollAmount_SmallIncrement, UIA_CheckBoxControlTypeId,
    UIA_NativeWindowHandlePropertyId, IUIAutomationElementArray,
    UIA_StyleNameAttributeId, IUIAutomationNotificationEventHandler,
    UIA_SeparatorControlTypeId, UIA_CulturePropertyId,
    StyleId_Heading1, RowOrColumnMajor_RowMajor,
    NotificationKind_ItemRemoved, UIA_ChangesEventId,
    NotificationKind_ActionCompleted, CUIAutomation,
    UIA_AnnotationAuthorPropertyId,
    UIA_LocalizedLandmarkTypePropertyId, UIA_ListControlTypeId,
    UIA_TablePatternId, UIA_WindowIsModalPropertyId,
    TreeScope_Ancestors, UIA_SpreadsheetPatternId, StyleId_Heading8,
    IUIAutomationTextEditPattern,
    UIA_IsWindowPatternAvailablePropertyId, UIA_ListItemControlTypeId,
    IUIAutomationElement7, UIA_DropTarget_DroppedEventId,
    UIA_LegacyIAccessibleKeyboardShortcutPropertyId,
    UIA_ActiveTextPositionChangedEventId,
    IUIAutomationSelectionItemPattern, UIA_ItemContainerPatternId,
    StyleId_Heading9, UIA_DockDockPositionPropertyId,
    AnnotationType_Highlighted, UIA_ToolBarControlTypeId,
    UIA_MenuControlTypeId, UIA_HeadingLevelPropertyId,
    UIA_ScrollPatternId, UIA_ToolTipClosedEventId,
    SynchronizedInputType_RightMouseUp, UIA_OutlineStylesAttributeId,
    UIA_TableControlTypeId, IUIAutomationAndCondition, VARIANT,
    UIA_IsSubscriptAttributeId, IUIAutomationTreeWalker,
    ExpandCollapseState_Collapsed, StyleId_Quote,
    UIA_SelectionItem_ElementAddedToSelectionEventId, tagPOINT,
    UIA_Selection2LastSelectedItemPropertyId,
    SupportedTextSelection_Single, RowOrColumnMajor_ColumnMajor,
    IUIAutomationTogglePattern, AnnotationType_ExternalChange,
    IUIAutomationObjectModelPattern,
    UIA_IsInvokePatternAvailablePropertyId, IUIAutomation3,
    StyleId_Normal, UIA_ForegroundColorAttributeId, StyleId_Heading7,
    UIA_OverlineStyleAttributeId, WindowVisualState_Maximized,
    IUIAutomationElement, TextUnit_Document,
    IUIAutomationProxyFactoryEntry, UIA_BackgroundColorAttributeId,
    UIA_SpreadsheetItemFormulaPropertyId, NavigateDirection_LastChild,
    IUIAutomationTablePattern, IDispatch,
    UIA_AnnotationObjectsPropertyId, UIA_IsEnabledPropertyId,
    UIA_ExpandCollapsePatternId, TreeScope_Descendants,
    NotificationKind_ActionAborted, WindowVisualState_Minimized,
    AnnotationType_Comment, StyleId_NumberedList,
    UIA_IsLegacyIAccessiblePatternAvailablePropertyId,
    ProviderOptions_HasNativeIAccessible, UiaChangeInfo,
    ScrollAmount_NoAmount, IUIAutomation5,
    NotificationProcessing_ImportantAll, UIA_SummaryChangeId,
    UIA_IsOffscreenPropertyId, IUIAutomationProxyFactoryMapping,
    UIA_Drag_DragCompleteEventId, UIA_Invoke_InvokedEventId,
    UIA_StylesStyleIdPropertyId, UIA_DragGrabbedItemsPropertyId,
    UIA_HorizontalTextAlignmentAttributeId, IUIAutomationTextRange,
    TextUnit_Paragraph, UIA_TitleBarControlTypeId,
    UIA_TextChildPatternId, UIA_GridItemPatternId,
    UIA_IsMultipleViewPatternAvailablePropertyId,
    IUIAutomationMultipleViewPattern,
    UIA_Text_TextSelectionChangedEventId, UIA_ToolTipControlTypeId,
    UIA_TextFlowDirectionsAttributeId, AutomationElementMode_Full,
    UIA_SizeOfSetPropertyId, UIA_NamePropertyId, UIA_InvokePatternId,
    IUIAutomationSpreadsheetItemPattern,
    UIA_AnnotationAnnotationTypeIdPropertyId,
    UIA_WindowCanMaximizePropertyId,
    NotificationProcessing_CurrentThenMostRecent,
    IUIAutomationEventHandler, UIA_BoundingRectanglePropertyId,
    UIA_IsDropTargetPatternAvailablePropertyId,
    ProviderOptions_UseComThreading, TextPatternRangeEndpoint_End,
    UIA_ThumbControlTypeId, UIA_LegacyIAccessiblePatternId,
    RowOrColumnMajor_Indeterminate, NotificationKind_Other,
    DockPosition_Right, IUIAutomationVirtualizedItemPattern,
    UIA_IsControlElementPropertyId, UIA_MenuModeStartEventId,
    TreeTraversalOptions_Default, IUIAutomationEventHandlerGroup,
    UIA_IsValuePatternAvailablePropertyId, StyleId_Heading5,
    UIA_SelectionItem_ElementRemovedFromSelectionEventId,
    UIA_VisualEffectsPropertyId, UIA_AnnotationTypesPropertyId,
    UIA_DataGridControlTypeId,
    IUIAutomationStructureChangedEventHandler,
    AnnotationType_DataValidationError, UIA_GridColumnCountPropertyId,
    IUIAutomationElement5, IUIAutomationCacheRequest,
    UIA_RangeValueMaximumPropertyId, UIA_RuntimeIdPropertyId,
    ExpandCollapseState_PartiallyExpanded,
    StructureChangeType_ChildrenBulkAdded,
    UIA_TableRowHeadersPropertyId, UIA_AnnotationPatternId,
    StructureChangeType_ChildrenReordered, UIA_MenuOpenedEventId,
    UIA_DescribedByPropertyId, UIA_Transform2ZoomMaximumPropertyId,
    UIA_DataItemControlTypeId, IUIAutomationExpandCollapsePattern,
    UIA_WindowIsTopmostPropertyId, ZoomUnit_LargeDecrement,
    IUIAutomationElement6, UIA_SpinnerControlTypeId,
    UIA_TreeItemControlTypeId, IUIAutomationElement2,
    UIA_Selection2FirstSelectedItemPropertyId, AnnotationType_Header,
    UIA_RotationPropertyId, UIA_IsGridPatternAvailablePropertyId,
    UIA_IsTextPattern2AvailablePropertyId,
    UIA_RadioButtonControlTypeId, UIA_MultipleViewPatternId,
    UIA_WindowWindowInteractionStatePropertyId,
    UIA_ScrollItemPatternId, UIA_AutomationPropertyChangedEventId,
    UIA_StructureChangedEventId, NavigateDirection_FirstChild,
    NotificationProcessing_All, UIA_AcceleratorKeyPropertyId,
    StyleId_BulletedList, UIA_IsTextEditPatternAvailablePropertyId,
    UIA_IsItemContainerPatternAvailablePropertyId,
    UIA_IsContentElementPropertyId, UIA_LevelPropertyId,
    ExpandCollapseState_Expanded, UIA_TableItemPatternId,
    UIA_DockPatternId, UIA_ObjectModelPatternId,
    UIA_IsDataValidForFormPropertyId, IUIAutomationTextChildPattern,
    UIA_BulletStyleAttributeId, WSTRING, UIA_GridPatternId,
    UIA_AriaPropertiesPropertyId, AnnotationType_Sensitive,
    UIA_RangeValueSmallChangePropertyId, IUIAutomationTextPattern2,
    IUIAutomationElement4, ScrollAmount_LargeIncrement,
    UIA_IsReadOnlyAttributeId, UIA_LayoutInvalidatedEventId,
    SynchronizedInputType_LeftMouseDown, UIA_FrameworkIdPropertyId,
    UIA_ControlTypePropertyId,
    UIA_SpreadsheetItemAnnotationObjectsPropertyId,
    UIA_TextControlTypeId, IUIAutomationTextRange3,
    IUIAutomationOrCondition, UIA_AnimationStyleAttributeId,
    UIA_OutlineThicknessPropertyId, UIA_TransformCanRotatePropertyId,
    UIA_StyleIdAttributeId, SynchronizedInputType_KeyUp,
    UIA_TransformCanResizePropertyId, StyleId_Custom,
    UIA_MultipleViewCurrentViewPropertyId,
    UIA_TransformCanMovePropertyId,
    IUIAutomationLegacyIAccessiblePattern, UIA_MenuItemControlTypeId,
    UIA_IsTogglePatternAvailablePropertyId, StyleId_Emphasis,
    IUIAutomationTransformPattern,
    UIA_LegacyIAccessibleStatePropertyId,
    UIA_InputReachedTargetEventId, UIA_CultureAttributeId, tagRECT,
    UIA_IsDockPatternAvailablePropertyId,
    AnnotationType_EditingLockedChange, HeadingLevel5,
    AnnotationType_MoveChange, UIA_RangeValueMinimumPropertyId,
    IUIAutomationTransformPattern2, UIA_SemanticZoomControlTypeId,
    ProviderOptions_NonClientAreaProvider,
    UIA_GridItemColumnPropertyId,
    UIA_IsTextPatternAvailablePropertyId, UIA_WindowPatternId,
    UIA_TextEdit_TextChangedEventId, UIA_CenterPointPropertyId,
    OrientationType_Vertical, UIA_ClassNamePropertyId,
    UIA_RangeValueValuePropertyId, IUIAutomationNotCondition,
    UIA_DragPatternId, AnnotationType_Unknown,
    UIA_IsSpreadsheetPatternAvailablePropertyId, StyleId_Heading3,
    UIA_MainLandmarkTypeId, UIA_IsTransformPatternAvailablePropertyId,
    UIA_MultipleViewSupportedViewsPropertyId,
    UIA_ProviderDescriptionPropertyId,
    StructureChangeType_ChildrenInvalidated,
    ExpandCollapseState_LeafNode, UIA_ValueIsReadOnlyPropertyId,
    TextEditChangeType_None, IUIAutomation2,
    WindowInteractionState_ReadyForUserInteraction,
    IUIAutomationStylesPattern,
    WindowInteractionState_BlockedByModalWindow,
    ProviderOptions_OverrideProvider,
    UIA_SelectionItem_ElementSelectedEventId,
    UIA_LegacyIAccessibleHelpPropertyId,
    UIA_HostedFragmentRootsInvalidatedEventId,
    TreeTraversalOptions_LastToFirstOrder,
    UIA_ScrollVerticalViewSizePropertyId, Library,
    PropertyConditionFlags_None, HeadingLevel1, TreeScope_Subtree,
    UIA_IsTablePatternAvailablePropertyId,
    IUIAutomationTextRangeArray,
    UIA_IsTableItemPatternAvailablePropertyId,
    AnnotationType_UnsyncedChange, UIA_LineSpacingAttributeId,
    SynchronizedInputType_KeyDown,
    UIA_IsTextChildPatternAvailablePropertyId,
    UIA_AppBarControlTypeId,
    UIA_TextEdit_ConversionTargetChangedEventId,
    UIA_SelectionIsSelectionRequiredPropertyId,
    UIA_GridItemRowPropertyId, UIA_IndentationFirstLineAttributeId,
    IUIAutomationSelectionPattern2, UIA_ItemTypePropertyId,
    UIA_UnderlineColorAttributeId, UIA_AnnotationTypesAttributeId,
    UIA_ProcessIdPropertyId, DockPosition_Top, ToggleState_Off,
    NavigateDirection_NextSibling, IUIAutomationRangeValuePattern,
    UIA_OrientationPropertyId, UIA_RangeValueIsReadOnlyPropertyId,
    SynchronizedInputType_RightMouseDown, UIA_LabeledByPropertyId,
    UIA_ProgressBarControlTypeId, UIA_StylesStyleNamePropertyId,
    UIA_FontWeightAttributeId, ScrollAmount_LargeDecrement,
    TreeTraversalOptions_PostOrder,
    AnnotationType_CircularReferenceError,
    UIA_IsVirtualizedItemPatternAvailablePropertyId, IAccessible,
    UIA_Transform2ZoomMinimumPropertyId,
    UIA_IsSelectionPattern2AvailablePropertyId,
    UIA_IsPasswordPropertyId, UIA_FormLandmarkTypeId,
    UIA_StylesShapePropertyId, CoClass, UIA_ValuePatternId,
    UIA_CaretPositionAttributeId, SupportedTextSelection_None,
    IUIAutomationPropertyChangedEventHandler,
    UIA_LegacyIAccessibleNamePropertyId, ZoomUnit_SmallIncrement,
    IUIAutomationAnnotationPattern, HeadingLevel4,
    UIA_TabsAttributeId, UIA_FullDescriptionPropertyId,
    AnnotationType_FormatChange,
    UIA_IsAnnotationPatternAvailablePropertyId, UIA_LinkAttributeId,
    IUIAutomationTextEditTextChangedEventHandler,
    WindowInteractionState_NotResponding, UIA_TransformPattern2Id,
    WindowInteractionState_Running,
    UIA_RangeValueLargeChangePropertyId,
    IUIAutomationCustomNavigationPattern, HeadingLevel8,
    UIA_TransformPatternId, ProviderOptions_UseClientCoordinates,
    TextUnit_Page, StyleId_Heading6, UIA_SelectionItemPatternId,
    UIA_IsItalicAttributeId, UIA_DragDropEffectsPropertyId,
    UIA_SpreadsheetItemPatternId, TextEditChangeType_AutoCorrect,
    HeadingLevel2, UIA_AsyncContentLoadedEventId,
    UIA_LegacyIAccessibleSelectionPropertyId,
    UIA_AutomationIdPropertyId,
    UIA_OptimizeForVisualContentPropertyId, UIA_InputDiscardedEventId,
    UIA_ScrollVerticalScrollPercentPropertyId, UIA_MenuModeEndEventId,
    UIA_AnnotationDateTimePropertyId, UIA_StylesPatternId, dispid,
    TextUnit_Line, WindowVisualState_Normal, UIA_ButtonControlTypeId,
    IUIAutomationProxyFactory,
    UIA_DropTargetDropTargetEffectPropertyId, UIA_GroupControlTypeId,
    UIA_IsStylesPatternAvailablePropertyId, UIA_DocumentControlTypeId,
    UIA_StylesFillPatternColorPropertyId,
    WindowInteractionState_Closing, UIA_FlowsToPropertyId,
    UIA_FontNameAttributeId, AnnotationType_GrammarError,
    UIA_GridItemColumnSpanPropertyId, UIA_SystemAlertEventId,
    UIA_Text_TextChangedEventId,
    UIA_IsScrollPatternAvailablePropertyId,
    PropertyConditionFlags_MatchSubstring, UIA_TabItemControlTypeId,
    UIA_ToolTipOpenedEventId, IRawElementProviderSimple,
    UIA_IsDragPatternAvailablePropertyId,
    UIA_IsSuperscriptAttributeId, NotificationProcessing_MostRecent,
    TextEditChangeType_AutoComplete, Off,
    UIA_MarginTrailingAttributeId,
    UIA_StylesFillPatternStylePropertyId, HeadingLevel_None,
    UIA_TreeControlTypeId, TextEditChangeType_Composition,
    UIA_TableItemRowHeaderItemsPropertyId,
    UIA_LegacyIAccessibleChildIdPropertyId, Assertive,
    TreeScope_Parent, UIA_IsSelectionPatternAvailablePropertyId,
    UIA_InputReachedOtherElementEventId,
    IUIAutomationDropTargetPattern, AnnotationType_Author,
    IUIAutomationBoolCondition, IUIAutomationDragPattern,
    UIA_Selection_InvalidatedEventId, NavigateDirection_Parent,
    TextPatternRangeEndpoint_Start,
    UIA_SpreadsheetItemAnnotationTypesPropertyId,
    UIA_IsRequiredForFormPropertyId,
    UIA_ScrollVerticallyScrollablePropertyId,
    TextEditChangeType_CompositionFinalized,
    IUIAutomationSpreadsheetPattern, IUIAutomationElement8,
    UIA_ClickablePointPropertyId, COMMETHOD, AnnotationType_Footnote,
    UIA_FillTypePropertyId, UIA_TableItemColumnHeaderItemsPropertyId,
    UIA_LocalizedControlTypePropertyId, IUIAutomationTableItemPattern,
    UIA_SynchronizedInputPatternId, PropertyConditionFlags_IgnoreCase,
    UIA_DropTarget_DragLeaveEventId, UIA_ToggleToggleStatePropertyId,
    UIA_HeaderControlTypeId, IUIAutomationFocusChangedEventHandler,
    UIA_CaretBidiModeAttributeId, StructureChangeType_ChildRemoved,
    UIA_WindowWindowVisualStatePropertyId, UIA_OutlineColorPropertyId,
    SupportedTextSelection_Multiple, AnnotationType_InsertionChange,
    AnnotationType_FormulaError, UIA_FillColorPropertyId,
    ProviderOptions_RefuseNonClientSupport,
    SynchronizedInputType_LeftMouseUp, DockPosition_Bottom,
    AnnotationType_Endnote, IUIAutomationGridPattern,
    CoalesceEventsOptions_Enabled, UIA_TextPatternId,
    ConnectionRecoveryBehaviorOptions_Enabled, UIA_SizePropertyId,
    UIA_Window_WindowOpenedEventId, TreeScope_Element,
    NotificationProcessing_ImportantMostRecent, StyleId_Subtitle,
    UIA_MenuClosedEventId, TextUnit_Format, StyleId_Heading2,
    UIA_NotificationEventId,
    UIA_IsScrollItemPatternAvailablePropertyId,
    UIA_SelectionCanSelectMultiplePropertyId,
    UIA_AfterParagraphSpacingAttributeId,
    UIA_StylesFillColorPropertyId, UIA_DragDropEffectPropertyId,
    NotificationKind_ItemAdded, UIA_TextPattern2Id,
    UIA_LiveRegionChangedEventId, OrientationType_None,
    OrientationType_Horizontal, UIA_DropTargetPatternId,
    _midlSAFEARRAY, AnnotationType_DeletionChange,
    UIA_LegacyIAccessibleDefaultActionPropertyId,
    UIA_SelectionItemSelectionContainerPropertyId,
    UIA_PositionInSetPropertyId, IUIAutomationPropertyCondition,
    HeadingLevel7, UIA_IsSynchronizedInputPatternAvailablePropertyId,
    IUIAutomationWindowPattern, UIA_TabControlTypeId,
    UIA_ItemStatusPropertyId, ProviderOptions_ClientSideProvider,
    NavigateDirection_PreviousSibling,
    UIA_IndentationLeadingAttributeId, IUnknown,
    UIA_AriaRolePropertyId, DockPosition_Left,
    UIA_AutomationFocusChangedEventId,
    UIA_SelectionItemIsSelectedPropertyId,
    ProviderOptions_ProviderOwnsSetFocus,
    UIA_ExpandCollapseExpandCollapseStatePropertyId,
    UIA_AnnotationAnnotationTypeNamePropertyId,
    UIA_Selection2ItemCountPropertyId, UIA_StatusBarControlTypeId,
    TextUnit_Word, UIA_Drag_DragStartEventId, TreeScope_Children,
    UIA_SearchLandmarkTypeId, IUIAutomationScrollPattern,
    UIA_TableColumnHeadersPropertyId, _check_version,
    UIA_CustomLandmarkTypeId, UIA_ValueValuePropertyId,
    IUIAutomation6, UIA_LegacyIAccessibleDescriptionPropertyId,
    UIA_AccessKeyPropertyId, ProviderOptions_ServerSideProvider,
    UIA_HelpTextPropertyId, UIA_SayAsInterpretAsMetadataId,
    UIA_WindowCanMinimizePropertyId, UIA_PaneControlTypeId,
    AnnotationType_SpellingError, UIA_IndentationTrailingAttributeId,
    AnnotationType_AdvancedProofingIssue, AutomationElementMode_None,
    UIA_MarginBottomAttributeId, UIA_OverlineColorAttributeId, GUID,
    IUIAutomationItemContainerPattern,
    UIA_IsSelectionItemPatternAvailablePropertyId,
    UIA_GridItemContainingGridPropertyId, UIA_HyperlinkControlTypeId,
    DockPosition_Fill, UIA_Transform2ZoomLevelPropertyId,
    UIA_UnderlineStyleAttributeId, UIA_SelectionPatternId,
    UIA_IsRangeValuePatternAvailablePropertyId,
    UIA_IsHiddenAttributeId, IUIAutomation4,
    UIA_MarginLeadingAttributeId, UIA_SliderControlTypeId,
    UIA_CustomNavigationPatternId, IUIAutomationSelectionPattern,
    UIA_LandmarkTypePropertyId, UIA_WindowControlTypeId,
    IUIAutomationTextRange2, UIA_RangeValuePatternId,
    UIA_IsSpreadsheetItemPatternAvailablePropertyId,
    UIA_TogglePatternId, _lcid, IUIAutomationSynchronizedInputPattern,
    StyleId_Title, UIA_CalendarControlTypeId,
    UIA_SplitButtonControlTypeId, IUIAutomationScrollItemPattern,
    BSTR, IUIAutomationElement3, UIA_LegacyIAccessibleRolePropertyId,
    UIA_TextEditPatternId, TreeScope_None, UIA_MarginTopAttributeId,
    UIA_GridRowCountPropertyId,
    UIA_StylesExtendedPropertiesPropertyId,
    UIA_HasKeyboardFocusPropertyId, HRESULT,
    AnnotationType_TrackChanges, typelib_path,
    UIA_FontSizeAttributeId, UIA_SelectionActiveEndAttributeId,
    ZoomUnit_LargeIncrement,
    UIA_IsExpandCollapsePatternAvailablePropertyId,
    UIA_MenuBarControlTypeId, HeadingLevel3,
    UIA_LiveSettingPropertyId, UIA_AnnotationObjectsAttributeId,
    UIA_SelectionSelectionPropertyId, UIA_GridItemRowSpanPropertyId,
    IUIAutomationValuePattern, AnnotationType_Mathematics,
    ScrollAmount_SmallDecrement,
    UIA_IsGridItemPatternAvailablePropertyId,
    UIA_TableRowOrColumnMajorPropertyId,
    UIA_IsCustomNavigationPatternAvailablePropertyId,
    ZoomUnit_SmallDecrement, UIA_IsKeyboardFocusablePropertyId,
    IUIAutomationTextPattern, IUIAutomationChangesEventHandler,
    DockPosition_None, UIA_NavigationLandmarkTypeId,
    UIA_DropTargetDropTargetEffectsPropertyId,
    UIA_DropTarget_DragEnterEventId, StyleId_Heading4,
    UIA_SayAsInterpretAsAttributeId, UIA_IsPeripheralPropertyId,
    UIA_ScrollHorizontalViewSizePropertyId,
    UIA_ScrollHorizontallyScrollablePropertyId, HeadingLevel9,
    UIA_BeforeParagraphSpacingAttributeId,
    UIA_LegacyIAccessibleValuePropertyId, UIA_SelectionPattern2Id,
    UIA_FlowsFromPropertyId,
    UIA_IsObjectModelPatternAvailablePropertyId,
    UIA_Selection2CurrentSelectedItemPropertyId,
    UIA_Drag_DragCancelEventId, IUIAutomationInvokePattern,
    CoalesceEventsOptions_Disabled, UIA_ScrollBarControlTypeId,
    UIA_CustomControlTypeId
)


class TreeScope(IntFlag):
    TreeScope_None = 0
    TreeScope_Element = 1
    TreeScope_Children = 2
    TreeScope_Descendants = 4
    TreeScope_Parent = 8
    TreeScope_Ancestors = 16
    TreeScope_Subtree = 7


class OrientationType(IntFlag):
    OrientationType_None = 0
    OrientationType_Horizontal = 1
    OrientationType_Vertical = 2


class PropertyConditionFlags(IntFlag):
    PropertyConditionFlags_None = 0
    PropertyConditionFlags_IgnoreCase = 1
    PropertyConditionFlags_MatchSubstring = 2


class TextEditChangeType(IntFlag):
    TextEditChangeType_None = 0
    TextEditChangeType_AutoCorrect = 1
    TextEditChangeType_Composition = 2
    TextEditChangeType_CompositionFinalized = 3
    TextEditChangeType_AutoComplete = 4


class ConnectionRecoveryBehaviorOptions(IntFlag):
    ConnectionRecoveryBehaviorOptions_Disabled = 0
    ConnectionRecoveryBehaviorOptions_Enabled = 1


class CoalesceEventsOptions(IntFlag):
    CoalesceEventsOptions_Disabled = 0
    CoalesceEventsOptions_Enabled = 1


class WindowVisualState(IntFlag):
    WindowVisualState_Normal = 0
    WindowVisualState_Maximized = 1
    WindowVisualState_Minimized = 2


class TextPatternRangeEndpoint(IntFlag):
    TextPatternRangeEndpoint_Start = 0
    TextPatternRangeEndpoint_End = 1


class TextUnit(IntFlag):
    TextUnit_Character = 0
    TextUnit_Format = 1
    TextUnit_Word = 2
    TextUnit_Line = 3
    TextUnit_Paragraph = 4
    TextUnit_Page = 5
    TextUnit_Document = 6


class WindowInteractionState(IntFlag):
    WindowInteractionState_Running = 0
    WindowInteractionState_Closing = 1
    WindowInteractionState_ReadyForUserInteraction = 2
    WindowInteractionState_BlockedByModalWindow = 3
    WindowInteractionState_NotResponding = 4


class LiveSetting(IntFlag):
    Off = 0
    Polite = 1
    Assertive = 2


class SupportedTextSelection(IntFlag):
    SupportedTextSelection_None = 0
    SupportedTextSelection_Single = 1
    SupportedTextSelection_Multiple = 2


class ProviderOptions(IntFlag):
    ProviderOptions_ClientSideProvider = 1
    ProviderOptions_ServerSideProvider = 2
    ProviderOptions_NonClientAreaProvider = 4
    ProviderOptions_OverrideProvider = 8
    ProviderOptions_ProviderOwnsSetFocus = 16
    ProviderOptions_UseComThreading = 32
    ProviderOptions_RefuseNonClientSupport = 64
    ProviderOptions_HasNativeIAccessible = 128
    ProviderOptions_UseClientCoordinates = 256


class NavigateDirection(IntFlag):
    NavigateDirection_Parent = 0
    NavigateDirection_NextSibling = 1
    NavigateDirection_PreviousSibling = 2
    NavigateDirection_FirstChild = 3
    NavigateDirection_LastChild = 4


class AutomationElementMode(IntFlag):
    AutomationElementMode_None = 0
    AutomationElementMode_Full = 1


class RowOrColumnMajor(IntFlag):
    RowOrColumnMajor_RowMajor = 0
    RowOrColumnMajor_ColumnMajor = 1
    RowOrColumnMajor_Indeterminate = 2


class TreeTraversalOptions(IntFlag):
    TreeTraversalOptions_Default = 0
    TreeTraversalOptions_PostOrder = 1
    TreeTraversalOptions_LastToFirstOrder = 2


class NotificationKind(IntFlag):
    NotificationKind_ItemAdded = 0
    NotificationKind_ItemRemoved = 1
    NotificationKind_ActionCompleted = 2
    NotificationKind_ActionAborted = 3
    NotificationKind_Other = 4


class NotificationProcessing(IntFlag):
    NotificationProcessing_ImportantAll = 0
    NotificationProcessing_ImportantMostRecent = 1
    NotificationProcessing_All = 2
    NotificationProcessing_MostRecent = 3
    NotificationProcessing_CurrentThenMostRecent = 4


class ScrollAmount(IntFlag):
    ScrollAmount_LargeDecrement = 0
    ScrollAmount_SmallDecrement = 1
    ScrollAmount_NoAmount = 2
    ScrollAmount_LargeIncrement = 3
    ScrollAmount_SmallIncrement = 4


class ToggleState(IntFlag):
    ToggleState_Off = 0
    ToggleState_On = 1
    ToggleState_Indeterminate = 2


class DockPosition(IntFlag):
    DockPosition_Top = 0
    DockPosition_Left = 1
    DockPosition_Bottom = 2
    DockPosition_Right = 3
    DockPosition_Fill = 4
    DockPosition_None = 5


class ZoomUnit(IntFlag):
    ZoomUnit_NoAmount = 0
    ZoomUnit_LargeDecrement = 1
    ZoomUnit_SmallDecrement = 2
    ZoomUnit_LargeIncrement = 3
    ZoomUnit_SmallIncrement = 4


class ExpandCollapseState(IntFlag):
    ExpandCollapseState_Collapsed = 0
    ExpandCollapseState_Expanded = 1
    ExpandCollapseState_PartiallyExpanded = 2
    ExpandCollapseState_LeafNode = 3


class StructureChangeType(IntFlag):
    StructureChangeType_ChildAdded = 0
    StructureChangeType_ChildRemoved = 1
    StructureChangeType_ChildrenInvalidated = 2
    StructureChangeType_ChildrenBulkAdded = 3
    StructureChangeType_ChildrenBulkRemoved = 4
    StructureChangeType_ChildrenReordered = 5


class SynchronizedInputType(IntFlag):
    SynchronizedInputType_KeyUp = 1
    SynchronizedInputType_KeyDown = 2
    SynchronizedInputType_LeftMouseUp = 4
    SynchronizedInputType_LeftMouseDown = 8
    SynchronizedInputType_RightMouseUp = 16
    SynchronizedInputType_RightMouseDown = 32


__all__ = [
    'Polite', 'UIA_EditControlTypeId', 'AnnotationType_Footer',
    'UIA_AnnotationTargetPropertyId',
    'AnnotationType_ConflictingChange', 'IUIAutomationCondition',
    'UIA_DragIsGrabbedPropertyId', 'TextUnit_Character',
    'ZoomUnit_NoAmount', 'IUIAutomationElement9',
    'UIA_ScrollHorizontalScrollPercentPropertyId',
    'ToggleState_Indeterminate',
    'UIA_IsTransformPattern2AvailablePropertyId',
    'ConnectionRecoveryBehaviorOptions_Disabled',
    'UIA_ImageControlTypeId', 'PropertyConditionFlags',
    'UIA_CapStyleAttributeId', 'UIA_IsDialogPropertyId',
    'UIA_ComboBoxControlTypeId', 'UIA_HeaderItemControlTypeId',
    'UIA_Window_WindowClosedEventId',
    'UIA_Transform2CanZoomPropertyId', 'UIA_VirtualizedItemPatternId',
    'IUIAutomation', 'StructureChangeType_ChildAdded',
    'IUIAutomationActiveTextPositionChangedEventHandler',
    'UIA_ControllerForPropertyId',
    'UIA_StrikethroughStyleAttributeId',
    'UIA_StrikethroughColorAttributeId',
    'StructureChangeType_ChildrenBulkRemoved',
    'IUIAutomationDockPattern', 'ToggleState_On',
    'IUIAutomationGridItemPattern', 'HeadingLevel6',
    'ExtendedProperty', 'CUIAutomation8', 'UIA_IsActiveAttributeId',
    'ScrollAmount_SmallIncrement', 'UIA_CheckBoxControlTypeId',
    'UIA_NativeWindowHandlePropertyId', 'IUIAutomationElementArray',
    'UIA_StyleNameAttributeId', 'NotificationProcessing',
    'IUIAutomationNotificationEventHandler',
    'UIA_SeparatorControlTypeId', 'UIA_CulturePropertyId',
    'StyleId_Heading1', 'RowOrColumnMajor_RowMajor',
    'NotificationKind_ItemRemoved', 'UIA_ChangesEventId',
    'NotificationKind_ActionCompleted', 'OrientationType',
    'ConnectionRecoveryBehaviorOptions', 'CUIAutomation',
    'UIA_AnnotationAuthorPropertyId',
    'UIA_LocalizedLandmarkTypePropertyId', 'UIA_ListControlTypeId',
    'UIA_TablePatternId', 'UIA_WindowIsModalPropertyId',
    'TreeScope_Ancestors', 'UIA_SpreadsheetPatternId',
    'StyleId_Heading8', 'IUIAutomationTextEditPattern',
    'UIA_IsWindowPatternAvailablePropertyId',
    'UIA_ListItemControlTypeId', 'IUIAutomationElement7',
    'UIA_DropTarget_DroppedEventId',
    'UIA_LegacyIAccessibleKeyboardShortcutPropertyId',
    'UIA_ActiveTextPositionChangedEventId',
    'IUIAutomationSelectionItemPattern', 'UIA_ItemContainerPatternId',
    'StyleId_Heading9', 'UIA_DockDockPositionPropertyId',
    'AnnotationType_Highlighted', 'UIA_ToolBarControlTypeId',
    'UIA_MenuControlTypeId', 'UIA_HeadingLevelPropertyId',
    'ProviderOptions', 'UIA_ScrollPatternId',
    'UIA_ToolTipClosedEventId', 'SynchronizedInputType_RightMouseUp',
    'UIA_OutlineStylesAttributeId', 'UIA_TableControlTypeId',
    'IUIAutomationAndCondition', 'UIA_IsSubscriptAttributeId',
    'IUIAutomationTreeWalker', 'ExpandCollapseState_Collapsed',
    'StyleId_Quote',
    'UIA_SelectionItem_ElementAddedToSelectionEventId',
    'UIA_Selection2LastSelectedItemPropertyId',
    'SupportedTextSelection_Single', 'RowOrColumnMajor_ColumnMajor',
    'IUIAutomationTogglePattern', 'AnnotationType_ExternalChange',
    'IUIAutomationObjectModelPattern',
    'UIA_IsInvokePatternAvailablePropertyId', 'IUIAutomation3',
    'StyleId_Normal', 'UIA_ForegroundColorAttributeId',
    'StyleId_Heading7', 'UIA_OverlineStyleAttributeId',
    'WindowVisualState_Maximized', 'IUIAutomationElement',
    'TextUnit_Document', 'IUIAutomationProxyFactoryEntry',
    'UIA_BackgroundColorAttributeId',
    'UIA_SpreadsheetItemFormulaPropertyId',
    'NavigateDirection_LastChild', 'IUIAutomationTablePattern',
    'UIA_AnnotationObjectsPropertyId', 'UIA_IsEnabledPropertyId',
    'UIA_ExpandCollapsePatternId', 'TreeScope_Descendants',
    'NotificationKind_ActionAborted', 'WindowVisualState_Minimized',
    'AnnotationType_Comment', 'StyleId_NumberedList',
    'TreeTraversalOptions',
    'UIA_IsLegacyIAccessiblePatternAvailablePropertyId',
    'ProviderOptions_HasNativeIAccessible', 'UiaChangeInfo',
    'ScrollAmount_NoAmount', 'IUIAutomation5',
    'NotificationProcessing_ImportantAll', 'UIA_SummaryChangeId',
    'UIA_IsOffscreenPropertyId', 'TextUnit',
    'IUIAutomationProxyFactoryMapping',
    'UIA_Drag_DragCompleteEventId', 'UIA_Invoke_InvokedEventId',
    'UIA_StylesStyleIdPropertyId', 'UIA_DragGrabbedItemsPropertyId',
    'UIA_HorizontalTextAlignmentAttributeId',
    'IUIAutomationTextRange', 'TextUnit_Paragraph',
    'UIA_TitleBarControlTypeId', 'UIA_TextChildPatternId',
    'UIA_GridItemPatternId',
    'UIA_IsMultipleViewPatternAvailablePropertyId',
    'IUIAutomationMultipleViewPattern',
    'UIA_Text_TextSelectionChangedEventId',
    'UIA_ToolTipControlTypeId', 'UIA_TextFlowDirectionsAttributeId',
    'AutomationElementMode_Full', 'UIA_SizeOfSetPropertyId',
    'UIA_NamePropertyId', 'UIA_InvokePatternId',
    'StructureChangeType', 'IUIAutomationSpreadsheetItemPattern',
    'ExpandCollapseState', 'UIA_AnnotationAnnotationTypeIdPropertyId',
    'UIA_WindowCanMaximizePropertyId',
    'NotificationProcessing_CurrentThenMostRecent',
    'IUIAutomationEventHandler', 'UIA_BoundingRectanglePropertyId',
    'UIA_IsDropTargetPatternAvailablePropertyId',
    'ProviderOptions_UseComThreading', 'TextPatternRangeEndpoint_End',
    'TextPatternRangeEndpoint', 'UIA_ThumbControlTypeId',
    'UIA_LegacyIAccessiblePatternId',
    'RowOrColumnMajor_Indeterminate', 'NotificationKind_Other',
    'DockPosition_Right', 'IUIAutomationVirtualizedItemPattern',
    'UIA_IsControlElementPropertyId', 'UIA_MenuModeStartEventId',
    'TreeTraversalOptions_Default', 'IUIAutomationEventHandlerGroup',
    'UIA_IsValuePatternAvailablePropertyId', 'StyleId_Heading5',
    'UIA_SelectionItem_ElementRemovedFromSelectionEventId',
    'UIA_VisualEffectsPropertyId', 'UIA_AnnotationTypesPropertyId',
    'UIA_DataGridControlTypeId',
    'IUIAutomationStructureChangedEventHandler',
    'AnnotationType_DataValidationError',
    'UIA_GridColumnCountPropertyId', 'IUIAutomationElement5',
    'WindowVisualState', 'IUIAutomationCacheRequest',
    'UIA_RangeValueMaximumPropertyId', 'UIA_RuntimeIdPropertyId',
    'ExpandCollapseState_PartiallyExpanded',
    'StructureChangeType_ChildrenBulkAdded',
    'UIA_TableRowHeadersPropertyId', 'UIA_AnnotationPatternId',
    'StructureChangeType_ChildrenReordered', 'UIA_MenuOpenedEventId',
    'UIA_DescribedByPropertyId',
    'UIA_Transform2ZoomMaximumPropertyId',
    'UIA_DataItemControlTypeId', 'IUIAutomationExpandCollapsePattern',
    'UIA_WindowIsTopmostPropertyId', 'ZoomUnit_LargeDecrement',
    'IUIAutomationElement6', 'UIA_SpinnerControlTypeId',
    'UIA_TreeItemControlTypeId', 'IUIAutomationElement2',
    'UIA_Selection2FirstSelectedItemPropertyId',
    'AnnotationType_Header', 'UIA_RotationPropertyId',
    'UIA_IsGridPatternAvailablePropertyId',
    'UIA_IsTextPattern2AvailablePropertyId',
    'UIA_RadioButtonControlTypeId', 'UIA_MultipleViewPatternId',
    'UIA_WindowWindowInteractionStatePropertyId',
    'UIA_ScrollItemPatternId', 'UIA_AutomationPropertyChangedEventId',
    'UIA_StructureChangedEventId', 'NavigateDirection_FirstChild',
    'NotificationProcessing_All', 'UIA_AcceleratorKeyPropertyId',
    'StyleId_BulletedList',
    'UIA_IsTextEditPatternAvailablePropertyId',
    'UIA_IsItemContainerPatternAvailablePropertyId',
    'UIA_IsContentElementPropertyId', 'UIA_LevelPropertyId',
    'ExpandCollapseState_Expanded', 'UIA_TableItemPatternId',
    'UIA_DockPatternId', 'UIA_ObjectModelPatternId',
    'UIA_IsDataValidForFormPropertyId',
    'IUIAutomationTextChildPattern', 'UIA_BulletStyleAttributeId',
    'UIA_GridPatternId', 'UIA_AriaPropertiesPropertyId',
    'AnnotationType_Sensitive', 'UIA_RangeValueSmallChangePropertyId',
    'IUIAutomationTextPattern2', 'IUIAutomationElement4',
    'ScrollAmount_LargeIncrement', 'ToggleState',
    'UIA_IsReadOnlyAttributeId', 'UIA_LayoutInvalidatedEventId',
    'SynchronizedInputType_LeftMouseDown',
    'UIA_FrameworkIdPropertyId', 'UIA_ControlTypePropertyId',
    'UIA_SpreadsheetItemAnnotationObjectsPropertyId',
    'UIA_TextControlTypeId', 'IUIAutomationTextRange3',
    'IUIAutomationOrCondition', 'UIA_AnimationStyleAttributeId',
    'UIA_OutlineThicknessPropertyId',
    'UIA_TransformCanRotatePropertyId', 'UIA_StyleIdAttributeId',
    'SynchronizedInputType_KeyUp', 'UIA_TransformCanResizePropertyId',
    'StyleId_Custom', 'UIA_MultipleViewCurrentViewPropertyId',
    'UIA_TransformCanMovePropertyId',
    'IUIAutomationLegacyIAccessiblePattern',
    'UIA_MenuItemControlTypeId',
    'UIA_IsTogglePatternAvailablePropertyId', 'StyleId_Emphasis',
    'IUIAutomationTransformPattern',
    'UIA_LegacyIAccessibleStatePropertyId',
    'UIA_InputReachedTargetEventId', 'UIA_CultureAttributeId',
    'DockPosition', 'UIA_IsDockPatternAvailablePropertyId',
    'AnnotationType_EditingLockedChange', 'HeadingLevel5',
    'AnnotationType_MoveChange', 'UIA_RangeValueMinimumPropertyId',
    'IUIAutomationTransformPattern2', 'UIA_SemanticZoomControlTypeId',
    'ProviderOptions_NonClientAreaProvider',
    'UIA_GridItemColumnPropertyId',
    'UIA_IsTextPatternAvailablePropertyId', 'UIA_WindowPatternId',
    'UIA_TextEdit_TextChangedEventId', 'UIA_CenterPointPropertyId',
    'OrientationType_Vertical', 'UIA_ClassNamePropertyId',
    'UIA_RangeValueValuePropertyId', 'IUIAutomationNotCondition',
    'UIA_DragPatternId', 'AnnotationType_Unknown',
    'UIA_IsSpreadsheetPatternAvailablePropertyId', 'StyleId_Heading3',
    'UIA_MainLandmarkTypeId',
    'UIA_IsTransformPatternAvailablePropertyId',
    'UIA_MultipleViewSupportedViewsPropertyId', 'LiveSetting',
    'UIA_ProviderDescriptionPropertyId',
    'StructureChangeType_ChildrenInvalidated',
    'ExpandCollapseState_LeafNode', 'UIA_ValueIsReadOnlyPropertyId',
    'TextEditChangeType_None', 'IUIAutomation2',
    'WindowInteractionState_ReadyForUserInteraction',
    'IUIAutomationStylesPattern',
    'WindowInteractionState_BlockedByModalWindow',
    'ProviderOptions_OverrideProvider',
    'UIA_SelectionItem_ElementSelectedEventId',
    'UIA_LegacyIAccessibleHelpPropertyId',
    'UIA_HostedFragmentRootsInvalidatedEventId',
    'TreeTraversalOptions_LastToFirstOrder',
    'UIA_ScrollVerticalViewSizePropertyId', 'Library',
    'PropertyConditionFlags_None', 'HeadingLevel1',
    'AutomationElementMode', 'TreeScope_Subtree',
    'WindowInteractionState', 'UIA_IsTablePatternAvailablePropertyId',
    'IUIAutomationTextRangeArray',
    'UIA_IsTableItemPatternAvailablePropertyId',
    'AnnotationType_UnsyncedChange', 'UIA_LineSpacingAttributeId',
    'SynchronizedInputType_KeyDown',
    'UIA_IsTextChildPatternAvailablePropertyId',
    'UIA_AppBarControlTypeId',
    'UIA_TextEdit_ConversionTargetChangedEventId',
    'UIA_SelectionIsSelectionRequiredPropertyId',
    'UIA_GridItemRowPropertyId',
    'UIA_IndentationFirstLineAttributeId',
    'IUIAutomationSelectionPattern2', 'UIA_ItemTypePropertyId',
    'UIA_UnderlineColorAttributeId', 'UIA_AnnotationTypesAttributeId',
    'UIA_ProcessIdPropertyId', 'SynchronizedInputType',
    'DockPosition_Top', 'ToggleState_Off', 'CoalesceEventsOptions',
    'NavigateDirection_NextSibling', 'IUIAutomationRangeValuePattern',
    'UIA_OrientationPropertyId', 'UIA_RangeValueIsReadOnlyPropertyId',
    'SynchronizedInputType_RightMouseDown', 'UIA_LabeledByPropertyId',
    'UIA_ProgressBarControlTypeId', 'UIA_StylesStyleNamePropertyId',
    'UIA_FontWeightAttributeId', 'ScrollAmount_LargeDecrement',
    'TreeTraversalOptions_PostOrder',
    'AnnotationType_CircularReferenceError',
    'UIA_IsVirtualizedItemPatternAvailablePropertyId', 'IAccessible',
    'UIA_Transform2ZoomMinimumPropertyId',
    'UIA_IsSelectionPattern2AvailablePropertyId',
    'UIA_IsPasswordPropertyId', 'UIA_FormLandmarkTypeId',
    'UIA_StylesShapePropertyId', 'UIA_ValuePatternId',
    'UIA_CaretPositionAttributeId', 'SupportedTextSelection_None',
    'IUIAutomationPropertyChangedEventHandler',
    'UIA_LegacyIAccessibleNamePropertyId', 'ZoomUnit_SmallIncrement',
    'IUIAutomationAnnotationPattern', 'HeadingLevel4',
    'UIA_TabsAttributeId', 'UIA_FullDescriptionPropertyId',
    'AnnotationType_FormatChange',
    'UIA_IsAnnotationPatternAvailablePropertyId',
    'UIA_LinkAttributeId',
    'IUIAutomationTextEditTextChangedEventHandler',
    'WindowInteractionState_NotResponding', 'UIA_TransformPattern2Id',
    'WindowInteractionState_Running',
    'UIA_RangeValueLargeChangePropertyId', 'RowOrColumnMajor',
    'IUIAutomationCustomNavigationPattern', 'HeadingLevel8',
    'UIA_TransformPatternId', 'ProviderOptions_UseClientCoordinates',
    'TextUnit_Page', 'StyleId_Heading6', 'UIA_SelectionItemPatternId',
    'UIA_IsItalicAttributeId', 'UIA_DragDropEffectsPropertyId',
    'UIA_SpreadsheetItemPatternId', 'TextEditChangeType_AutoCorrect',
    'HeadingLevel2', 'UIA_AsyncContentLoadedEventId',
    'UIA_LegacyIAccessibleSelectionPropertyId',
    'UIA_AutomationIdPropertyId',
    'UIA_OptimizeForVisualContentPropertyId',
    'UIA_InputDiscardedEventId',
    'UIA_ScrollVerticalScrollPercentPropertyId',
    'UIA_MenuModeEndEventId', 'UIA_AnnotationDateTimePropertyId',
    'UIA_StylesPatternId', 'TextUnit_Line',
    'WindowVisualState_Normal', 'UIA_ButtonControlTypeId',
    'IUIAutomationProxyFactory',
    'UIA_DropTargetDropTargetEffectPropertyId',
    'UIA_GroupControlTypeId', 'TreeScope',
    'UIA_IsStylesPatternAvailablePropertyId',
    'UIA_DocumentControlTypeId',
    'UIA_StylesFillPatternColorPropertyId',
    'WindowInteractionState_Closing', 'UIA_FlowsToPropertyId',
    'UIA_FontNameAttributeId', 'AnnotationType_GrammarError',
    'UIA_GridItemColumnSpanPropertyId', 'UIA_SystemAlertEventId',
    'UIA_Text_TextChangedEventId',
    'UIA_IsScrollPatternAvailablePropertyId',
    'PropertyConditionFlags_MatchSubstring',
    'UIA_TabItemControlTypeId', 'NotificationKind',
    'UIA_ToolTipOpenedEventId', 'IRawElementProviderSimple',
    'UIA_IsDragPatternAvailablePropertyId',
    'UIA_IsSuperscriptAttributeId',
    'NotificationProcessing_MostRecent',
    'TextEditChangeType_AutoComplete', 'Off',
    'UIA_MarginTrailingAttributeId',
    'UIA_StylesFillPatternStylePropertyId', 'HeadingLevel_None',
    'UIA_TreeControlTypeId', 'TextEditChangeType_Composition',
    'UIA_TableItemRowHeaderItemsPropertyId',
    'UIA_LegacyIAccessibleChildIdPropertyId', 'Assertive',
    'TreeScope_Parent', 'UIA_IsSelectionPatternAvailablePropertyId',
    'UIA_InputReachedOtherElementEventId', 'NavigateDirection',
    'IUIAutomationDropTargetPattern', 'AnnotationType_Author',
    'IUIAutomationBoolCondition', 'IUIAutomationDragPattern',
    'UIA_Selection_InvalidatedEventId', 'NavigateDirection_Parent',
    'TextPatternRangeEndpoint_Start',
    'UIA_SpreadsheetItemAnnotationTypesPropertyId',
    'UIA_IsRequiredForFormPropertyId',
    'UIA_ScrollVerticallyScrollablePropertyId',
    'TextEditChangeType_CompositionFinalized',
    'IUIAutomationSpreadsheetPattern', 'IUIAutomationElement8',
    'UIA_ClickablePointPropertyId', 'AnnotationType_Footnote',
    'UIA_FillTypePropertyId',
    'UIA_TableItemColumnHeaderItemsPropertyId',
    'UIA_LocalizedControlTypePropertyId',
    'IUIAutomationTableItemPattern', 'UIA_SynchronizedInputPatternId',
    'PropertyConditionFlags_IgnoreCase',
    'UIA_DropTarget_DragLeaveEventId',
    'UIA_ToggleToggleStatePropertyId', 'UIA_HeaderControlTypeId',
    'IUIAutomationFocusChangedEventHandler',
    'UIA_CaretBidiModeAttributeId',
    'StructureChangeType_ChildRemoved',
    'UIA_WindowWindowVisualStatePropertyId',
    'UIA_OutlineColorPropertyId', 'SupportedTextSelection_Multiple',
    'AnnotationType_InsertionChange', 'SupportedTextSelection',
    'AnnotationType_FormulaError', 'UIA_FillColorPropertyId',
    'ZoomUnit', 'ProviderOptions_RefuseNonClientSupport',
    'SynchronizedInputType_LeftMouseUp', 'DockPosition_Bottom',
    'AnnotationType_Endnote', 'IUIAutomationGridPattern',
    'CoalesceEventsOptions_Enabled', 'UIA_TextPatternId',
    'ConnectionRecoveryBehaviorOptions_Enabled', 'UIA_SizePropertyId',
    'UIA_Window_WindowOpenedEventId', 'TreeScope_Element',
    'NotificationProcessing_ImportantMostRecent', 'StyleId_Subtitle',
    'UIA_MenuClosedEventId', 'TextUnit_Format', 'StyleId_Heading2',
    'UIA_NotificationEventId',
    'UIA_IsScrollItemPatternAvailablePropertyId',
    'UIA_SelectionCanSelectMultiplePropertyId',
    'UIA_AfterParagraphSpacingAttributeId',
    'UIA_StylesFillColorPropertyId', 'UIA_DragDropEffectPropertyId',
    'NotificationKind_ItemAdded', 'UIA_TextPattern2Id',
    'UIA_LiveRegionChangedEventId', 'OrientationType_None',
    'OrientationType_Horizontal', 'UIA_DropTargetPatternId',
    'AnnotationType_DeletionChange',
    'UIA_LegacyIAccessibleDefaultActionPropertyId',
    'UIA_SelectionItemSelectionContainerPropertyId',
    'UIA_PositionInSetPropertyId', 'IUIAutomationPropertyCondition',
    'HeadingLevel7',
    'UIA_IsSynchronizedInputPatternAvailablePropertyId',
    'IUIAutomationWindowPattern', 'UIA_TabControlTypeId',
    'UIA_ItemStatusPropertyId', 'ProviderOptions_ClientSideProvider',
    'NavigateDirection_PreviousSibling',
    'UIA_IndentationLeadingAttributeId', 'UIA_AriaRolePropertyId',
    'DockPosition_Left', 'UIA_AutomationFocusChangedEventId',
    'UIA_SelectionItemIsSelectedPropertyId',
    'ProviderOptions_ProviderOwnsSetFocus',
    'UIA_ExpandCollapseExpandCollapseStatePropertyId',
    'UIA_AnnotationAnnotationTypeNamePropertyId',
    'UIA_Selection2ItemCountPropertyId', 'UIA_StatusBarControlTypeId',
    'TextUnit_Word', 'UIA_Drag_DragStartEventId',
    'TreeScope_Children', 'UIA_SearchLandmarkTypeId',
    'IUIAutomationScrollPattern', 'UIA_TableColumnHeadersPropertyId',
    'UIA_CustomLandmarkTypeId', 'UIA_ValueValuePropertyId',
    'IUIAutomation6', 'UIA_LegacyIAccessibleDescriptionPropertyId',
    'UIA_AccessKeyPropertyId', 'ProviderOptions_ServerSideProvider',
    'UIA_HelpTextPropertyId', 'UIA_SayAsInterpretAsMetadataId',
    'UIA_WindowCanMinimizePropertyId', 'UIA_PaneControlTypeId',
    'AnnotationType_SpellingError',
    'UIA_IndentationTrailingAttributeId',
    'AnnotationType_AdvancedProofingIssue',
    'AutomationElementMode_None', 'UIA_MarginBottomAttributeId',
    'TextEditChangeType', 'UIA_OverlineColorAttributeId',
    'IUIAutomationItemContainerPattern',
    'UIA_IsSelectionItemPatternAvailablePropertyId',
    'UIA_GridItemContainingGridPropertyId',
    'UIA_HyperlinkControlTypeId', 'DockPosition_Fill',
    'UIA_Transform2ZoomLevelPropertyId',
    'UIA_UnderlineStyleAttributeId', 'UIA_SelectionPatternId',
    'UIA_IsRangeValuePatternAvailablePropertyId',
    'UIA_IsHiddenAttributeId', 'IUIAutomation4',
    'UIA_MarginLeadingAttributeId', 'UIA_SliderControlTypeId',
    'UIA_CustomNavigationPatternId', 'IUIAutomationSelectionPattern',
    'UIA_LandmarkTypePropertyId', 'UIA_WindowControlTypeId',
    'IUIAutomationTextRange2', 'UIA_RangeValuePatternId',
    'UIA_IsSpreadsheetItemPatternAvailablePropertyId',
    'UIA_TogglePatternId', 'IUIAutomationSynchronizedInputPattern',
    'StyleId_Title', 'UIA_CalendarControlTypeId',
    'UIA_SplitButtonControlTypeId', 'IUIAutomationScrollItemPattern',
    'IUIAutomationElement3', 'UIA_LegacyIAccessibleRolePropertyId',
    'UIA_TextEditPatternId', 'TreeScope_None',
    'UIA_MarginTopAttributeId', 'UIA_GridRowCountPropertyId',
    'UIA_StylesExtendedPropertiesPropertyId',
    'UIA_HasKeyboardFocusPropertyId', 'AnnotationType_TrackChanges',
    'typelib_path', 'UIA_FontSizeAttributeId',
    'UIA_SelectionActiveEndAttributeId', 'ZoomUnit_LargeIncrement',
    'UIA_IsExpandCollapsePatternAvailablePropertyId',
    'UIA_MenuBarControlTypeId', 'HeadingLevel3',
    'UIA_LiveSettingPropertyId', 'UIA_AnnotationObjectsAttributeId',
    'UIA_SelectionSelectionPropertyId',
    'UIA_GridItemRowSpanPropertyId', 'IUIAutomationValuePattern',
    'AnnotationType_Mathematics', 'ScrollAmount_SmallDecrement',
    'UIA_IsGridItemPatternAvailablePropertyId',
    'UIA_TableRowOrColumnMajorPropertyId',
    'UIA_IsCustomNavigationPatternAvailablePropertyId',
    'ZoomUnit_SmallDecrement', 'UIA_IsKeyboardFocusablePropertyId',
    'IUIAutomationTextPattern', 'IUIAutomationChangesEventHandler',
    'DockPosition_None', 'UIA_NavigationLandmarkTypeId',
    'UIA_DropTargetDropTargetEffectsPropertyId', 'ScrollAmount',
    'UIA_DropTarget_DragEnterEventId', 'StyleId_Heading4',
    'UIA_SayAsInterpretAsAttributeId', 'UIA_IsPeripheralPropertyId',
    'UIA_ScrollHorizontalViewSizePropertyId',
    'UIA_ScrollHorizontallyScrollablePropertyId', 'HeadingLevel9',
    'UIA_BeforeParagraphSpacingAttributeId',
    'UIA_LegacyIAccessibleValuePropertyId', 'UIA_SelectionPattern2Id',
    'UIA_FlowsFromPropertyId',
    'UIA_IsObjectModelPatternAvailablePropertyId',
    'UIA_Selection2CurrentSelectedItemPropertyId',
    'UIA_Drag_DragCancelEventId', 'IUIAutomationInvokePattern',
    'CoalesceEventsOptions_Disabled', 'UIA_ScrollBarControlTypeId',
    'UIA_CustomControlTypeId'
]

