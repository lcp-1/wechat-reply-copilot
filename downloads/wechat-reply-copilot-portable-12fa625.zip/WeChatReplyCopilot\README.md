# WeChat Reply Copilot

Local Windows assistant for drafting replies in personal WeChat.

Chinese usage guide: [使用说明.md](使用说明.md)

Current capabilities:

- It supports both legacy `WeChat.exe` and WeChat 4.x `Weixin.exe`.
- It reads visible WeChat text through Windows UI Automation.
- It stores data locally in SQLite.
- It learns from outgoing messages the user explicitly collected.
- It generates drafts through the configured cloud API.
- Mode 1 only pre-fills the first message and never presses Enter.
- Mode 2 sends only after an explicit confirmation in the desktop dialog.

## Setup

For a source archive, install Python 3.11 and double-click `setup.cmd`, then
run `start.cmd`.

The portable archive includes its own Python runtime and does not require a
separate Python installation. Open the extracted `WeChatReplyCopilot` folder
and run `portable-launcher.cmd`.

## Main entry

Double-click:

`start.cmd`

The menu contains:

1. Test the API connection.
2. Collect the currently open WeChat chat.
3. Show collected style-sample counts.
4. Rebuild the global style profile.
5. Rebuild one contact or group style profile.
6. Generate three reply drafts.
7. Show the latest saved drafts.
8. Update API settings.
9. Update the stored API key.
10. Show config and database paths.

## Recommended workflow

1. Open a WeChat contact or group.
2. Scroll upward to load older messages.
3. Run `start.cmd` and select `2` to collect the visible chat.
4. Repeat scrolling and collection several times.
5. Repeat for several contacts.
6. Select `4` to rebuild the global style profile.
7. Select `5`, enter the contact name, and build its contact profile.
8. Select `6` to generate drafts.

Each collection run deduplicates messages. Only outgoing messages are added
to the style library.

## Files

- Project config: `config.local.toml`
- Database: `%LOCALAPPDATA%\WeChatReplyCopilot\data.sqlite3`
- Raw UI snapshot: `artifacts\inspect-latest.json`
- Parsed snapshot: `artifacts\parsed-latest.json`
- Latest drafts: `artifacts\drafts-latest.json`

API keys are stored in Windows Credential Manager and are not written to the
repository.

## Advanced CLI

The underlying CLI remains available:

```powershell
.\.venv\Scripts\wrc.exe --help
```

The GUI wrapper is intentionally kept to one file: `start.cmd`.
