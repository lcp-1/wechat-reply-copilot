from PIL import Image, ImageDraw

from wechat_reply_copilot.wechat_screen import classify_message_side


def test_green_bubble_on_right_is_outgoing() -> None:
    image = Image.new("RGB", (200, 100), "white")
    ImageDraw.Draw(image).rectangle((110, 10, 190, 90), fill=(140, 230, 100))

    side = classify_message_side(
        image,
        item_rect=(0, 0, 200, 100),
        list_rect=(0, 0, 200, 100),
        window_origin=(0, 0),
    )

    assert side == "outgoing"


def test_dark_content_on_left_is_incoming() -> None:
    image = Image.new("RGB", (200, 100), "white")
    draw = ImageDraw.Draw(image)
    for y in range(15, 90, 10):
        draw.rectangle((15, y, 85, y + 4), fill=(30, 30, 30))

    side = classify_message_side(
        image,
        item_rect=(0, 0, 200, 100),
        list_rect=(0, 0, 200, 100),
        window_origin=(0, 0),
    )

    assert side == "incoming"


def test_image_content_on_right_is_outgoing_without_green_bubble() -> None:
    image = Image.new("RGB", (200, 100), "white")
    draw = ImageDraw.Draw(image)
    for y in range(15, 90, 10):
        draw.rectangle((115, y, 185, y + 4), fill=(30, 80, 180))

    side = classify_message_side(
        image,
        item_rect=(0, 0, 200, 100),
        list_rect=(0, 0, 200, 100),
        window_origin=(0, 0),
    )

    assert side == "outgoing"
