from wechat_reply_copilot.models import UiNode, WindowSnapshot
from wechat_reply_copilot.parser import (
    ConversationSummary,
    ParsedMessage,
    _detect_chat_kind,
    _parse_active_chat,
    parse_snapshot,
)


def test_group_chat_is_detected_from_member_count() -> None:
    nodes = [
        UiNode(depth=0, control_type="Text", name="项目群 (12)"),
        UiNode(depth=0, control_type="Text", name="(12)"),
        UiNode(depth=0, control_type="Button", name="聊天信息"),
    ]

    kind = _detect_chat_kind(
        nodes,
        active_chat="项目群",
        current_user="CHU PING",
        conversations=[],
        messages=[],
    )

    assert kind == "group"


def test_direct_chat_is_detected_from_single_incoming_sender() -> None:
    kind = _detect_chat_kind(
        [],
        active_chat="张三",
        current_user="CHU PING",
        conversations=[
            ConversationSummary(
                display_name="张三",
                last_message_time="12:00",
                last_message_preview="你好",
            )
        ],
        messages=[
            ParsedMessage(sender="张三", direction="incoming", content="你好"),
        ],
    )

    assert kind == "direct"


def test_quoted_message_keeps_reference_text() -> None:
    nodes = [
        UiNode(depth=0, control_type="List", name="消息"),
        UiNode(
            depth=1,
            control_type="ListItem",
            name="收到啦\n引用 CHU PING 的消息 : 前面说的话",
        ),
        UiNode(depth=2, control_type="Pane", name=""),
        UiNode(depth=3, control_type="Button", name="wls"),
        UiNode(depth=3, control_type="Pane", name=""),
        UiNode(depth=4, control_type="Button", name="CHU PING"),
    ]

    _, messages = _parse_active_chat(nodes, current_user="CHU PING")

    assert messages == [
        ParsedMessage(
            sender="wls",
            direction="incoming",
            content="收到啦\n引用 CHU PING 的消息 : 前面说的话",
        )
    ]


def test_wechat4_snapshot_parses_direct_chat_and_bubble_sides() -> None:
    nodes = [
        UiNode(0, "ToolBar", "导航", class_name="mmui::MainTabBar"),
        UiNode(1, "Button", "微信", class_name="mmui::XTabBarItem"),
        UiNode(0, "Group", "", class_name="mmui::ChatTitleBarChatSingleView"),
        UiNode(0, "Edit", "My girl", class_name="mmui::ChatInputField"),
        UiNode(0, "List", "消息", class_name="mmui::RecyclerListView"),
        UiNode(1, "ListItem", "12:51", class_name="mmui::ChatItemView"),
        UiNode(
            1,
            "ListItem",
            "晚安～",
            automation_id="chat_message_list.qt_scrollarea_viewport.chat_bubble_item_view",
            class_name="mmui::ChatTextItemView",
            horizontal_side="incoming",
        ),
        UiNode(
            1,
            "ListItem",
            "今天天气真不错[呲牙]",
            automation_id="chat_message_list.qt_scrollarea_viewport.chat_bubble_item_view",
            class_name="mmui::ChatTextItemView",
            horizontal_side="outgoing",
        ),
        UiNode(0, "List", "会话", class_name="mmui::XTableView"),
        UiNode(
            1,
            "ListItem",
            "My girl\n今天天气真不错[呲牙]\n12:51",
            class_name="mmui::ChatSessionCell",
        ),
    ]
    snapshot = WindowSnapshot.create(
        window_title="微信",
        process_path="Weixin.exe",
        nodes=nodes,
    )

    parsed = parse_snapshot(snapshot)

    assert parsed.active_chat == "My girl"
    assert parsed.chat_kind == "direct"
    assert parsed.messages == [
        ParsedMessage(sender="My girl", direction="incoming", content="晚安～"),
        ParsedMessage(sender=None, direction="outgoing", content="今天天气真不错[呲牙]"),
    ]
    assert parsed.conversations == [
        ConversationSummary(
            display_name="My girl",
            last_message_time="12:51",
            last_message_preview="今天天气真不错[呲牙]",
        )
    ]


def test_wechat4_group_title_view_is_detected_as_group() -> None:
    kind = _detect_chat_kind(
        [UiNode(0, "Group", "", class_name="mmui::ChatTitleBarChatRoomView")],
        active_chat="项目群",
        current_user=None,
        conversations=[],
        messages=[],
    )

    assert kind == "group"
