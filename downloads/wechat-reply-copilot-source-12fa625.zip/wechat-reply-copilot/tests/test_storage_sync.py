from pathlib import Path

from wechat_reply_copilot.parser import ParsedMessage, ParsedSnapshot
from wechat_reply_copilot.storage import style_stats, sync_parsed_snapshot


def test_sync_parsed_snapshot_collects_only_outgoing_style_samples(tmp_path: Path) -> None:
    database_path = tmp_path / "data.sqlite3"
    parsed = ParsedSnapshot(
        active_chat="测试联系人",
        current_user="CHU PING",
        conversations=[],
        messages=[
            ParsedMessage(sender="测试联系人", direction="incoming", content="你好"),
            ParsedMessage(sender="CHU PING", direction="outgoing", content="好呀"),
        ],
    )

    result = sync_parsed_snapshot(database_path, parsed)
    stats = style_stats(database_path)

    assert result["inserted_messages"] == 2
    assert result["inserted_style_samples"] == 1
    assert stats["global_samples"] == 1


def test_sync_stores_incoming_only_context_without_style_samples(tmp_path: Path) -> None:
    database_path = tmp_path / "data.sqlite3"
    parsed = ParsedSnapshot(
        active_chat="只有对方发言",
        current_user="CHU PING",
        conversations=[],
        messages=[
            ParsedMessage(sender="对方", direction="incoming", content="第一条"),
            ParsedMessage(sender="对方", direction="incoming", content="第二条"),
            ParsedMessage(sender="对方", direction="incoming", content="第三条"),
        ],
    )

    result = sync_parsed_snapshot(database_path, parsed)
    stats = style_stats(database_path)
    conversation = stats["conversation_stats"][0]

    assert result["inserted_messages"] == 3
    assert result["inserted_style_samples"] == 0
    assert stats["global_samples"] == 0
    assert conversation["messages"] == 3
    assert conversation["incoming_messages"] == 3
    assert conversation["samples"] == 0
