from pathlib import Path

from wechat_reply_copilot.storage import database_summary, initialize_database


def test_initialize_database_creates_schema(tmp_path: Path) -> None:
    database_path = tmp_path / "data.sqlite3"

    initialize_database(database_path)
    summary = database_summary(database_path)

    assert summary["exists"] is True
    assert summary["tables"]["messages"] == 0
    assert summary["tables"]["style_samples"] == 0
