from wechat_reply_copilot.parser import ParsedMessage, ParsedSnapshot
from wechat_reply_copilot.watcher import (
    _latest_incoming,
    _latest_incoming_fingerprint,
)


def snapshot(messages: list[ParsedMessage]) -> ParsedSnapshot:
    return ParsedSnapshot(
        active_chat="张三",
        current_user="CHU PING",
        conversations=[],
        messages=messages,
        chat_kind="direct",
    )


def test_existing_unanswered_message_is_treated_as_pending() -> None:
    parsed = snapshot(
        [
            ParsedMessage(sender="CHU PING", direction="outgoing", content="之前的回复"),
            ParsedMessage(sender="张三", direction="incoming", content="看过但还没回复"),
        ]
    )

    assert _latest_incoming(parsed.messages) == parsed.messages[-1]
    assert _latest_incoming_fingerprint(parsed) is not None


def test_latest_outgoing_message_is_not_pending() -> None:
    parsed = snapshot(
        [
            ParsedMessage(sender="张三", direction="incoming", content="问题"),
            ParsedMessage(sender="CHU PING", direction="outgoing", content="已经回复"),
        ]
    )

    assert _latest_incoming(parsed.messages) is None
    assert _latest_incoming_fingerprint(parsed) is None


def test_new_incoming_message_changes_pending_fingerprint() -> None:
    first = snapshot(
        [ParsedMessage(sender="张三", direction="incoming", content="第一条")]
    )
    second = snapshot(
        [ParsedMessage(sender="张三", direction="incoming", content="第二条")]
    )

    assert _latest_incoming_fingerprint(first) != _latest_incoming_fingerprint(second)
