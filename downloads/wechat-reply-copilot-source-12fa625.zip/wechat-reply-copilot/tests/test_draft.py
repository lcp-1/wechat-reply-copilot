from wechat_reply_copilot.config import AppConfig, ProviderConfig
from wechat_reply_copilot.draft import (
    _build_reply_context,
    _parse_drafts,
    generate_drafts,
)


def test_pending_block_includes_all_messages_after_last_outgoing() -> None:
    messages = [
        {"sender": "对方", "direction": "incoming", "content": "之前的问题"},
        {"sender": "CHU PING", "direction": "outgoing", "content": "之前的回复"},
        {"sender": "对方", "direction": "incoming", "content": "第一段"},
        {"sender": "对方", "direction": "incoming", "content": "第二段"},
        {"sender": "对方", "direction": "incoming", "content": "第三段"},
    ]

    context, pending = _build_reply_context(messages, current_user="CHU PING")

    assert context == messages[:2]
    assert pending == messages[2:]


def test_latest_outgoing_message_blocks_drafting() -> None:
    messages = [
        {"sender": "对方", "direction": "incoming", "content": "问题"},
        {"sender": "CHU PING", "direction": "outgoing", "content": "已经回复"},
    ]

    context, pending = _build_reply_context(messages, current_user="CHU PING")

    assert context == []
    assert pending == []


def test_unknown_message_with_other_sender_is_treated_as_incoming() -> None:
    messages = [
        {"sender": "对方", "direction": "unknown", "content": "只有我来发言"},
    ]

    context, pending = _build_reply_context(messages, current_user="CHU PING")

    assert context == []
    assert pending == [
        {"sender": "对方", "direction": "incoming", "content": "只有我来发言"}
    ]


def test_reply_context_is_limited_before_pending_block() -> None:
    messages = [
        {"sender": "对方", "direction": "incoming", "content": f"背景 {index}"}
        for index in range(12)
    ]
    messages.append(
        {"sender": "CHU PING", "direction": "outgoing", "content": "最后一条回复"}
    )
    messages.append({"sender": "对方", "direction": "incoming", "content": "待回复"})

    context, pending = _build_reply_context(
        messages,
        current_user="CHU PING",
        context_limit=5,
    )

    assert context == messages[8:13]
    assert pending == messages[13:]


def test_parse_drafts_normalizes_wechat_emoji_codes() -> None:
    drafts = _parse_drafts(
        '{"drafts": [{"label": "轻松", "text": "没事[捂脸] 好的", "reason": ""}]}'
    )

    assert drafts[0]["messages"] == ["没事🤦 好的"]


def test_parse_drafts_supports_multi_message_plans() -> None:
    drafts = _parse_drafts(
        '{"drafts": [{"label": "分开回", "messages": ['
        '"这部分内容比较长而且包含一个需要单独说明的完整问题，因此不应强行合并", '
        '"另一部分也有足够长且相对独立的说明内容，继续保持为第二条消息"'
        '], "reason": ""}]}'
    )

    assert len(drafts[0]["messages"]) == 2


def test_parse_drafts_merges_short_over_split_plan() -> None:
    drafts = _parse_drafts(
        '{"drafts": [{"label": "简短", "messages": ["行吧", "那就不聊这个了"], '
        '"reason": ""}]}'
    )

    assert drafts[0]["messages"] == ["行吧，那就不聊这个了"]


def test_generate_drafts_passes_the_whole_pending_block(monkeypatch, tmp_path) -> None:
    config = AppConfig(
        provider=ProviderConfig(),
        database_path=tmp_path / "data.sqlite3",
    )
    captured: dict[str, str] = {}

    def fake_chat_completion(config, messages, *, temperature=0.3):
        del config, temperature
        captured["prompt"] = messages[1].content
        return '{"drafts": [{"label": "回复", "text": "好的", "reason": ""}]}'

    monkeypatch.setattr(
        "wechat_reply_copilot.draft.chat_completion",
        fake_chat_completion,
    )
    result = generate_drafts(
        config,
        conversation_name="张三",
        messages=[
            {"sender": "张三", "direction": "incoming", "content": "第一段"},
            {"sender": "张三", "direction": "incoming", "content": "第二段"},
            {"sender": "张三", "direction": "incoming", "content": "第三段"},
        ],
    )

    assert result["pending_message_count"] == 3
    assert "Pending messages to answer" in captured["prompt"]
    assert "第一段" in captured["prompt"]
    assert "第二段" in captured["prompt"]
    assert "第三段" in captured["prompt"]
    assert "Latest incoming message to answer" not in captured["prompt"]
