from types import SimpleNamespace

from wechat_reply_copilot import wechat_uia


def test_connect_wechat_accepts_both_old_and_new_process_names(monkeypatch) -> None:
    captured: dict[str, set[str]] = {}

    class Window:
        def __init__(self, handle: int) -> None:
            self.handle = handle
            self.element_info = SimpleNamespace(
                name="微信",
                class_name="Qt51514QWindowIcon",
            )

    def fake_find(process_names: set[str], window_title: str) -> int:
        assert window_title == "微信"
        captured["process_names"] = process_names
        return 5678

    monkeypatch.setattr(wechat_uia, "WeChatWindow", Window)
    monkeypatch.setattr(wechat_uia, "_find_wechat_handle", fake_find)

    window = wechat_uia.connect_wechat("WeChat.exe", "微信")

    assert window.handle == 5678
    assert captured["process_names"] == {"wechat.exe", "weixin.exe"}
