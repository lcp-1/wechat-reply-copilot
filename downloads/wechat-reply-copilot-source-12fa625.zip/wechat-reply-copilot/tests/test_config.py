from pathlib import Path

from wechat_reply_copilot.config import ProviderConfig, load_config


def test_api_key_accidentally_placed_in_env_name_is_ignored(tmp_path: Path) -> None:
    config_path = tmp_path / "config.toml"
    config_path.write_text(
        """
[provider]
api_key_env = "sk-example-secret"
""".strip(),
        encoding="utf-8",
    )

    config = load_config(config_path)

    assert config.provider.api_key_env == ProviderConfig.api_key_env
