import pytest

from wechat_reply_copilot.config import AppConfig, ProviderConfig
from wechat_reply_copilot.parser import ParsedMessage, ParsedSnapshot
from wechat_reply_copilot.sender import (
    SendError,
    _focus_edit,
    _normalize_reply_messages,
    _validate_target,
    _write_edit_text,
    send_reply_sequence,
)


def parsed(messages: list[ParsedMessage], active_chat: str = "张三") -> ParsedSnapshot:
    return ParsedSnapshot(
        active_chat=active_chat,
        current_user="CHU PING",
        conversations=[],
        messages=messages,
    )


def test_valid_direct_reply_target() -> None:
    snapshot = parsed(
        [
            ParsedMessage(sender="张三", direction="incoming", content="在吗"),
        ]
    )

    _validate_target(
        snapshot,
        conversation_name="张三",
        expected_incoming_content="在吗",
        text="在",
    )


def test_group_reply_target_is_rejected() -> None:
    snapshot = parsed(
        [
            ParsedMessage(sender="张三", direction="incoming", content="在吗"),
        ],
        active_chat="项目群",
    )

    with pytest.raises(SendError) as error:
        _validate_target(
            snapshot,
            conversation_name="项目群",
            expected_incoming_content="在吗",
            text="在",
        )
    assert error.value.reason == "non_direct"


def test_changed_target_message_is_rejected() -> None:
    snapshot = parsed(
        [
            ParsedMessage(sender="张三", direction="incoming", content="新消息"),
        ]
    )

    with pytest.raises(SendError):
        _validate_target(
            snapshot,
            conversation_name="张三",
            expected_incoming_content="旧消息",
            text="好",
        )


def test_manual_outgoing_message_after_target_does_not_block_reply() -> None:
    snapshot = parsed(
        [
            ParsedMessage(sender="张三", direction="incoming", content="在吗"),
            ParsedMessage(sender="CHU PING", direction="outgoing", content="在"),
        ]
    )

    _validate_target(
        snapshot,
        conversation_name="张三",
        expected_incoming_content="在吗",
        text="怎么了",
    )


def test_new_incoming_message_after_target_blocks_reply() -> None:
    snapshot = parsed(
        [
            ParsedMessage(sender="张三", direction="incoming", content="在吗"),
            ParsedMessage(sender="CHU PING", direction="outgoing", content="在"),
            ParsedMessage(sender="张三", direction="incoming", content="快说"),
        ]
    )

    with pytest.raises(SendError) as error:
        _validate_target(
            snapshot,
            conversation_name="张三",
            expected_incoming_content="在吗",
            text="怎么了",
        )

    assert error.value.reason == "target_changed"


def test_focus_edit_waits_for_async_focus(monkeypatch) -> None:
    class Window:
        def restore(self) -> None:
            pass

        def set_focus(self) -> None:
            pass

    class Edit:
        attempts = 0

        def set_focus(self) -> None:
            self.attempts += 1

        def has_keyboard_focus(self) -> bool:
            return self.attempts >= 3

    edit = Edit()
    monkeypatch.setattr("wechat_reply_copilot.sender._click_control", lambda control: None)
    _focus_edit(Window(), edit, timeout_seconds=0.5)

    assert edit.attempts == 3


def test_focus_edit_fails_after_timeout(monkeypatch) -> None:
    class Window:
        def restore(self) -> None:
            pass

        def set_focus(self) -> None:
            pass

    class Edit:
        def set_focus(self) -> None:
            pass

        def has_keyboard_focus(self) -> bool:
            return False

    monkeypatch.setattr("wechat_reply_copilot.sender._click_control", lambda control: None)

    with pytest.raises(SendError, match="did not receive keyboard focus"):
        _focus_edit(Window(), Edit(), timeout_seconds=0.01)


def test_write_edit_text_sends_unicode_code_units(monkeypatch) -> None:
    class Edit:
        def __init__(self) -> None:
            self.units: list[int] = []

        def get_value(self) -> str:
            encoded = b"".join(unit.to_bytes(2, "little") for unit in self.units)
            return encoded.decode("utf-16-le")

        def type_keys(self, keys: str) -> None:
            del keys

    class KeyAction:
        target: Edit

        def __init__(self, key: str) -> None:
            self.key = key

        def run(self) -> None:
            self.target.units.append(ord(self.key))

    edit = Edit()
    KeyAction.target = edit
    monkeypatch.setattr("wechat_reply_copilot.sender.KeyAction", KeyAction)

    _write_edit_text(edit, "测试🤦")

    assert edit.get_value() == "测试🤦"


def test_normalize_reply_messages_keeps_at_most_three_bubbles() -> None:
    messages = _normalize_reply_messages(["第一句", "第二句\n第三句", "", "第四句"])

    assert messages == ["第一句", "第二句", "第三句"]


def test_send_reply_sequence_sends_each_plan_message(monkeypatch, tmp_path) -> None:
    config = AppConfig(
        provider=ProviderConfig(),
        database_path=tmp_path / "data.sqlite3",
    )
    entered: list[str] = []

    class Edit:
        def __init__(self, name: str) -> None:
            self.name = name

        def type_keys(self, keys: str) -> None:
            assert keys == "{ENTER}"
            entered.append(self.name)

    prepared: list[str] = []

    def fake_prepare_reply(config, *, conversation_name, expected_incoming_content, text, dry_run):
        del config, conversation_name, expected_incoming_content, dry_run
        prepared.append(text)
        return Edit(text)

    def fake_prepare_follow_up(config, *, conversation_name, text):
        del config, conversation_name
        prepared.append(text)
        return Edit(text)

    sent: list[str] = []

    def fake_wait_for_outgoing(config, *, conversation_name, text):
        del config, conversation_name
        sent.append(text)

    monkeypatch.setattr("wechat_reply_copilot.sender.prepare_reply", fake_prepare_reply)
    monkeypatch.setattr(
        "wechat_reply_copilot.sender._prepare_follow_up",
        fake_prepare_follow_up,
    )
    monkeypatch.setattr(
        "wechat_reply_copilot.sender._wait_for_outgoing",
        fake_wait_for_outgoing,
    )

    result = send_reply_sequence(
        config,
        conversation_name="张三",
        expected_incoming_content="在吗",
        messages=["在的", "怎么了"],
    )

    assert prepared == ["在的", "怎么了"]
    assert entered == ["在的", "怎么了"]
    assert sent == ["在的", "怎么了"]
    assert result["messages"] == ["在的", "怎么了"]
