@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul
set PYTHONUTF8=1
if not exist ".venv\Scripts\wrc.exe" (
  echo The local Python environment is missing.
  echo Run setup.cmd first.
  pause
  exit /b 1
)
".venv\Scripts\wrc.exe" menu
if errorlevel 1 pause

