@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul
set PYTHONUTF8=1

if not exist ".venv\Scripts\python.exe" (
  where py >nul 2>nul
  if errorlevel 1 (
    echo Python 3.11 was not found.
    echo Install Python 3.11 from https://www.python.org/downloads/ and run setup.cmd again.
    pause
    exit /b 1
  )
  echo Creating Python environment...
  py -3.11 -m venv .venv
  if errorlevel 1 goto :failed
)

echo Installing dependencies...
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto :failed
".venv\Scripts\python.exe" -m pip install -e .
if errorlevel 1 goto :failed

echo.
echo Setup complete. Run start.cmd to open the menu.
pause
exit /b 0

:failed
echo.
echo Setup failed. Review the messages above.
pause
exit /b 1
