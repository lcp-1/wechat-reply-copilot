@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul
set PYTHONUTF8=1
"WeChatReplyCopilot.exe" menu
if errorlevel 1 pause
