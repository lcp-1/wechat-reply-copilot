param(
    [string]$DistPath = "",
    [switch]$TestApi
)

$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.IO.Compression.FileSystem
$root = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
Set-Location $root

if (git status --porcelain) {
    throw "Commit or stash working-tree changes before building release archives."
}

$python = Join-Path $root ".venv\Scripts\python.exe"
$ruff = Join-Path $root ".venv\Scripts\ruff.exe"
$pyinstaller = Join-Path $root ".venv\Scripts\pyinstaller.exe"
if (-not (Test-Path $pyinstaller)) {
    throw "PyInstaller is missing. Run: .venv\Scripts\python.exe -m pip install -e '.[build]'"
}

& $ruff check .
if ($LASTEXITCODE -ne 0) { throw "Ruff checks failed." }
& $python -m pytest -q
if ($LASTEXITCODE -ne 0) { throw "Tests failed." }

$sha = (git rev-parse --short HEAD).Trim()
$release = if ($DistPath) { (New-Item -ItemType Directory -Force $DistPath).FullName } else { Join-Path $root "release" }
New-Item -ItemType Directory -Force $release | Out-Null
Get-ChildItem -Path $release -Filter "wechat-reply-copilot-*.zip" -File -ErrorAction SilentlyContinue |
    Remove-Item -Force

$sourceZip = Join-Path $release "wechat-reply-copilot-source-$sha.zip"
$portableZip = Join-Path $release "wechat-reply-copilot-portable-$sha.zip"
$buildDir = Join-Path $root "build\pyinstaller"
$distDir = Join-Path $root "dist\portable"

Remove-Item -Recurse -Force $buildDir, $distDir -ErrorAction SilentlyContinue

git archive --format=zip --output=$sourceZip --prefix=wechat-reply-copilot/ HEAD
if ($LASTEXITCODE -ne 0) { throw "Could not create source archive." }

& $pyinstaller `
    --noconfirm `
    --clean `
    --onedir `
    --console `
    --name WeChatReplyCopilot `
    --distpath $distDir `
    --workpath $buildDir `
    --specpath $buildDir `
    --paths (Join-Path $root "src") `
    --collect-all keyring `
    --collect-all pywinauto `
    --collect-all comtypes `
    --hidden-import keyring.backends.Windows `
    (Join-Path $PSScriptRoot "wrc_entry.py")
if ($LASTEXITCODE -ne 0) { throw "PyInstaller build failed." }

$appDir = Join-Path $distDir "WeChatReplyCopilot"
Get-ChildItem -Path $root -Filter "*.md" -File | Copy-Item -Destination $appDir
Copy-Item (Join-Path $PSScriptRoot "portable-launcher.cmd") $appDir

$exe = Join-Path $appDir "WeChatReplyCopilot.exe"
& $exe --help | Out-Null
if ($LASTEXITCODE -ne 0) { throw "Packaged executable failed its smoke test." }
if ($TestApi) {
    & $exe test-api
    if ($LASTEXITCODE -ne 0) { throw "Packaged executable could not reach the configured API." }
}

Remove-Item -Force $portableZip -ErrorAction SilentlyContinue
[System.IO.Compression.ZipFile]::CreateFromDirectory(
    $appDir,
    $portableZip,
    [System.IO.Compression.CompressionLevel]::Optimal,
    $true
)

$hashes = @(
    "$((Get-FileHash $sourceZip -Algorithm SHA256).Hash)  $(Split-Path $sourceZip -Leaf)",
    "$((Get-FileHash $portableZip -Algorithm SHA256).Hash)  $(Split-Path $portableZip -Leaf)"
)
$hashes | Set-Content -Encoding UTF8 (Join-Path $release "SHA256SUMS.txt")

Write-Host "Created:"
$hashes | ForEach-Object { Write-Host "  $_" }
