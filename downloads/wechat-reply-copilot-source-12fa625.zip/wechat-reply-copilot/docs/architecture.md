# Architecture

## Safety boundary

Version 0.1 is read-only. It may inspect visible UI through Windows UI Automation,
store text locally, and generate drafts. It must not click, type, paste, or send in
WeChat.

## Planned pipeline

1. Detect a new message in a selected WeChat conversation.
2. Read visible text through UI Automation.
3. Normalize and deduplicate messages.
4. Retrieve a compact style profile and relevant examples of the user's sent messages.
5. Request two or three draft replies from a cloud model.
6. Show drafts in a separate window.
7. Copy or insert a selected draft only after an explicit user action.

## Data stores

- SQLite stores normalized conversations, messages, and style samples.
- API credentials are read from environment variables and never stored in the repository.
- Screenshots are not part of the default pipeline.

## Cloud API

The provider layer will use an OpenAI-compatible API endpoint. The initial provider
selection, endpoint, and model will be configured locally after the read-only inspector
is working.

