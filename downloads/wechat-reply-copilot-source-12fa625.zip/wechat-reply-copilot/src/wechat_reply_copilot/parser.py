from __future__ import annotations

import re
from dataclasses import asdict, dataclass

from .models import UiNode, WindowSnapshot

TIME_PATTERN = re.compile(
    r"^(?:\d{1,2}:\d{2}|昨天(?:\s+\d{1,2}:\d{2})?|"
    r"今天(?:\s+\d{1,2}:\d{2})?|星期[一二三四五六日天](?:\s+\d{1,2}:\d{2})?|"
    r"\d{1,2}月\d{1,2}日(?:\s+\d{1,2}:\d{2})?|"
    r"\d{1,2}/\d{1,2}(?:\s+\d{1,2}:\d{2})?|"
    r"\d{4}年\d{1,2}月\d{1,2}日(?:\s+\d{1,2}:\d{2})?)$"
)


@dataclass(frozen=True)
class ConversationSummary:
    display_name: str
    last_message_time: str | None
    last_message_preview: str | None


@dataclass(frozen=True)
class ParsedMessage:
    sender: str | None
    direction: str
    content: str


@dataclass(frozen=True)
class ParsedSnapshot:
    active_chat: str | None
    current_user: str | None
    conversations: list[ConversationSummary]
    messages: list[ParsedMessage]
    chat_kind: str = "unknown"

    def to_dict(self) -> dict:
        return {
            "active_chat": self.active_chat,
            "current_user": self.current_user,
            "chat_kind": self.chat_kind,
            "conversations": [asdict(item) for item in self.conversations],
            "messages": [asdict(item) for item in self.messages],
        }


def parse_snapshot(snapshot: WindowSnapshot) -> ParsedSnapshot:
    nodes = snapshot.nodes
    current_user = _find_current_user(nodes)
    conversations = _parse_conversations(nodes)
    active_chat, messages = _parse_active_chat(nodes, current_user)
    chat_kind = _detect_chat_kind(
        nodes,
        active_chat=active_chat,
        current_user=current_user,
        conversations=conversations,
        messages=messages,
    )
    return ParsedSnapshot(
        active_chat=active_chat,
        current_user=current_user,
        conversations=conversations,
        messages=messages,
        chat_kind=chat_kind,
    )


def _parse_conversations(nodes: list[UiNode]) -> list[ConversationSummary]:
    conversation_list_index = _find_node(nodes, control_type="List", name="会话")
    if conversation_list_index is None:
        return []

    results: list[ConversationSummary] = []
    for item in _direct_children(nodes, conversation_list_index):
        if item.node.control_type != "ListItem":
            continue
        descendants = _descendants(nodes, item.index)
        buttons = [node.name for node in descendants if node.control_type == "Button" and node.name]
        texts = [node.name for node in descendants if node.control_type == "Text" and node.name]
        name_lines = [line.strip() for line in item.node.name.splitlines() if line.strip()]
        display_name = buttons[0] if buttons else (texts[0] if texts else (name_lines[0] if name_lines else ""))
        if not display_name:
            continue

        remaining_texts = [text for text in texts if text != display_name]
        if not remaining_texts:
            remaining_texts = name_lines[1:]
        last_time = next(
            (text for text in reversed(remaining_texts) if TIME_PATTERN.match(text)),
            None,
        )
        preview_candidates = [
            text
            for text in remaining_texts
            if text != last_time
            and not TIME_PATTERN.match(text)
            and text not in {"已置顶", "消息免打扰"}
        ]
        preview = preview_candidates[-1] if preview_candidates else None
        results.append(
            ConversationSummary(
                display_name=display_name,
                last_message_time=last_time,
                last_message_preview=preview,
            )
        )
    return results


def _parse_active_chat(
    nodes: list[UiNode],
    current_user: str | None,
) -> tuple[str | None, list[ParsedMessage]]:
    message_list_index = _find_node(nodes, control_type="List", name="消息")
    if message_list_index is None:
        return None, []

    active_chat = _find_active_chat_title(nodes)
    messages: list[ParsedMessage] = []
    for item in _direct_children(nodes, message_list_index):
        if item.node.control_type != "ListItem":
            continue

        content = item.node.name.strip()
        descendants = _descendants(nodes, item.index)
        if "chat_bubble_item_view" in item.node.automation_id:
            if item.node.class_name == "mmui::ChatItemView" or not content:
                continue
            direction = item.node.horizontal_side or "unknown"
            if direction == "incoming":
                sender = active_chat
            elif direction == "outgoing":
                sender = current_user
            else:
                sender = None
            messages.append(
                ParsedMessage(
                    sender=sender,
                    direction=direction,
                    content=content,
                )
            )
            continue

        button_nodes = [
            node
            for node in descendants
            if node.control_type == "Button"
            and node.name
            and node.name != "查看更多消息"
        ]
        sender_depth = min((node.depth for node in button_nodes), default=None)
        sender_buttons = [
            node.name for node in button_nodes if node.depth == sender_depth
        ]

        if TIME_PATTERN.match(content) and not button_nodes:
            continue
        if not content:
            continue

        if sender_buttons and current_user and sender_buttons[0] == current_user:
            direction = "outgoing"
            sender = current_user
        elif sender_buttons:
            direction = "incoming"
            sender = sender_buttons[0]
        else:
            direction = "unknown"
            sender = None

        messages.append(
            ParsedMessage(
                sender=sender,
                direction=direction,
                content=content,
            )
        )
    return active_chat, messages


def _find_current_user(nodes: list[UiNode]) -> str | None:
    toolbar_index = _find_node(nodes, control_type="ToolBar", name="导航")
    if toolbar_index is None:
        return None
    for node in _descendants(nodes, toolbar_index):
        if node.control_type == "Button" and node.name not in {
            "微信",
            "通讯录",
            "收藏",
            "发现",
            "手机",
            "更多",
        }:
            return node.name
    return None


def _detect_chat_kind(
    nodes: list[UiNode],
    *,
    active_chat: str | None,
    current_user: str | None,
    conversations: list[ConversationSummary],
    messages: list[ParsedMessage],
) -> str:
    if not active_chat:
        return "unknown"

    class_names = {node.class_name for node in nodes}
    if any("ChatTitleBarChatSingleView" in name for name in class_names):
        return "direct"
    if any(
        marker in name
        for name in class_names
        for marker in ("ChatTitleBarChatRoom", "ChatTitleBarChatGroup")
    ):
        return "group"

    chat_info_index = _find_node(nodes, control_type="Button", name="聊天信息")
    if chat_info_index is not None:
        for node in reversed(nodes[max(0, chat_info_index - 25) : chat_info_index]):
            if node.control_type == "Text" and re.fullmatch(r"\(\d+\)", node.name):
                return "group"

    conversation = next(
        (item for item in conversations if item.display_name == active_chat),
        None,
    )
    if conversation and re.search(r"\(\d+\)\s*$", conversation.display_name):
        return "group"

    incoming_senders = {
        message.sender
        for message in messages
        if message.direction == "incoming" and message.sender
    }
    if incoming_senders:
        if any(sender != active_chat for sender in incoming_senders):
            return "group"
        return "direct"

    if current_user:
        return "direct"
    return "unknown"


def _find_active_chat_title(nodes: list[UiNode]) -> str | None:
    input_index = _find_node(
        nodes,
        control_type="Edit",
        class_name="mmui::ChatInputField",
    )
    if input_index is not None and nodes[input_index].name:
        return nodes[input_index].name.strip()

    chat_info_index = _find_node(nodes, control_type="Button", name="聊天信息")
    if chat_info_index is None:
        return None
    for node in reversed(nodes[:chat_info_index]):
        if node.control_type != "Text" or not node.name:
            continue
        if (
            node.name == "查看更多消息"
            or TIME_PATTERN.match(node.name)
            or re.fullmatch(r"\(\d+\)", node.name)
        ):
            continue
        return re.sub(r"\s*\(\d+\)$", "", node.name).strip()
    return None


def _find_node(
    nodes: list[UiNode],
    *,
    control_type: str | None = None,
    name: str | None = None,
    class_name: str | None = None,
) -> int | None:
    for index, node in enumerate(nodes):
        if control_type is not None and node.control_type != control_type:
            continue
        if name is not None and node.name != name:
            continue
        if class_name is not None and node.class_name != class_name:
            continue
        return index
    return None


@dataclass(frozen=True)
class _IndexedNode:
    index: int
    node: UiNode


def _direct_children(nodes: list[UiNode], parent_index: int) -> list[_IndexedNode]:
    parent = nodes[parent_index]
    results: list[_IndexedNode] = []
    for index in range(parent_index + 1, len(nodes)):
        node = nodes[index]
        if node.depth <= parent.depth:
            break
        if node.depth == parent.depth + 1:
            results.append(_IndexedNode(index=index, node=node))
    return results


def _descendants(nodes: list[UiNode], parent_index: int) -> list[UiNode]:
    parent = nodes[parent_index]
    results: list[UiNode] = []
    for node in nodes[parent_index + 1 :]:
        if node.depth <= parent.depth:
            break
        results.append(node)
    return results
