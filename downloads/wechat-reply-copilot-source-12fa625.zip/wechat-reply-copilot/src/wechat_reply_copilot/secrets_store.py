from __future__ import annotations

import os

import keyring
from keyring.errors import KeyringError

from .config import ProviderConfig


class SecretStoreError(RuntimeError):
    """Raised when an API key cannot be stored or loaded."""


def store_api_key(provider: ProviderConfig, api_key: str) -> None:
    value = api_key.strip()
    if not value:
        raise SecretStoreError("API key cannot be empty.")
    try:
        keyring.set_password(provider.keyring_service, provider.keyring_username, value)
    except KeyringError as exc:
        raise SecretStoreError(f"Could not write to Windows Credential Manager: {exc}") from exc


def delete_api_key(provider: ProviderConfig) -> None:
    try:
        keyring.delete_password(provider.keyring_service, provider.keyring_username)
    except keyring.errors.PasswordDeleteError:
        return
    except KeyringError as exc:
        raise SecretStoreError(f"Could not update Windows Credential Manager: {exc}") from exc


def load_api_key(provider: ProviderConfig) -> str | None:
    try:
        stored = keyring.get_password(provider.keyring_service, provider.keyring_username)
    except KeyringError as exc:
        raise SecretStoreError(f"Could not read Windows Credential Manager: {exc}") from exc
    if stored:
        return stored

    from_environment = os.environ.get(provider.api_key_env, "").strip()
    return from_environment or None


def api_key_source(provider: ProviderConfig) -> str:
    try:
        if keyring.get_password(provider.keyring_service, provider.keyring_username):
            return "windows-keyring"
    except KeyringError:
        pass
    if os.environ.get(provider.api_key_env, "").strip():
        return f"environment:{provider.api_key_env}"
    return "missing"
