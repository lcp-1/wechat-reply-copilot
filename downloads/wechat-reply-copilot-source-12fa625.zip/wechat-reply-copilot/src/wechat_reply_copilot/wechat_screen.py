from __future__ import annotations

import ctypes
from ctypes import wintypes
from dataclasses import replace

from PIL import Image, ImageFilter

from .models import UiNode


class _BitmapInfoHeader(ctypes.Structure):
    _fields_ = [
        ("biSize", wintypes.DWORD),
        ("biWidth", wintypes.LONG),
        ("biHeight", wintypes.LONG),
        ("biPlanes", wintypes.WORD),
        ("biBitCount", wintypes.WORD),
        ("biCompression", wintypes.DWORD),
        ("biSizeImage", wintypes.DWORD),
        ("biXPelsPerMeter", wintypes.LONG),
        ("biYPelsPerMeter", wintypes.LONG),
        ("biClrUsed", wintypes.DWORD),
        ("biClrImportant", wintypes.DWORD),
    ]


class _BitmapInfo(ctypes.Structure):
    _fields_ = [("bmiHeader", _BitmapInfoHeader), ("bmiColors", wintypes.DWORD * 3)]


def annotate_message_sides(nodes: list[UiNode], handle: int) -> None:
    image, window_rect = capture_window(handle)
    if image is None:
        return

    message_list_index = next(
        (
            index
            for index, node in enumerate(nodes)
            if node.control_type == "List" and node.name == "消息"
        ),
        None,
    )
    if message_list_index is None:
        return

    message_list = nodes[message_list_index]
    for index in range(message_list_index + 1, len(nodes)):
        node = nodes[index]
        if node.depth <= message_list.depth:
            break
        if node.depth != message_list.depth + 1:
            continue
        if "chat_bubble_item_view" not in node.automation_id:
            continue
        side = classify_message_side(
            image,
            item_rect=(node.left, node.top, node.right, node.bottom),
            list_rect=(
                message_list.left,
                message_list.top,
                message_list.right,
                message_list.bottom,
            ),
            window_origin=(window_rect[0], window_rect[1]),
        )
        if side:
            nodes[index] = replace(node, horizontal_side=side)


def capture_window(handle: int) -> tuple[Image.Image | None, tuple[int, int, int, int]]:
    user32 = ctypes.windll.user32
    gdi32 = ctypes.windll.gdi32
    rect = wintypes.RECT()
    if not user32.GetWindowRect(handle, ctypes.byref(rect)):
        return None, (0, 0, 0, 0)
    width = rect.right - rect.left
    height = rect.bottom - rect.top
    if width <= 0 or height <= 0:
        return None, (rect.left, rect.top, rect.right, rect.bottom)

    window_dc = user32.GetWindowDC(handle)
    memory_dc = gdi32.CreateCompatibleDC(window_dc)
    bitmap = gdi32.CreateCompatibleBitmap(window_dc, width, height)
    previous = gdi32.SelectObject(memory_dc, bitmap)
    try:
        if not user32.PrintWindow(handle, memory_dc, 2):
            return None, (rect.left, rect.top, rect.right, rect.bottom)

        bitmap_info = _BitmapInfo()
        bitmap_info.bmiHeader.biSize = ctypes.sizeof(_BitmapInfoHeader)
        bitmap_info.bmiHeader.biWidth = width
        bitmap_info.bmiHeader.biHeight = -height
        bitmap_info.bmiHeader.biPlanes = 1
        bitmap_info.bmiHeader.biBitCount = 32
        buffer = ctypes.create_string_buffer(width * height * 4)
        if not gdi32.GetDIBits(
            memory_dc,
            bitmap,
            0,
            height,
            buffer,
            ctypes.byref(bitmap_info),
            0,
        ):
            return None, (rect.left, rect.top, rect.right, rect.bottom)
        image = Image.frombuffer(
            "RGBA",
            (width, height),
            buffer,
            "raw",
            "BGRA",
            0,
            1,
        ).convert("RGB")
        return image, (rect.left, rect.top, rect.right, rect.bottom)
    finally:
        gdi32.SelectObject(memory_dc, previous)
        gdi32.DeleteObject(bitmap)
        gdi32.DeleteDC(memory_dc)
        user32.ReleaseDC(handle, window_dc)


def classify_message_side(
    image: Image.Image,
    *,
    item_rect: tuple[int, int, int, int],
    list_rect: tuple[int, int, int, int],
    window_origin: tuple[int, int],
) -> str:
    left, top, right, bottom = item_rect
    origin_x, origin_y = window_origin
    box = (
        max(0, left - origin_x),
        max(0, top - origin_y),
        min(image.width, right - origin_x),
        min(image.height, bottom - origin_y),
    )
    if box[2] <= box[0] or box[3] <= box[1]:
        return ""
    crop = image.crop(box)
    half = crop.width // 2
    left_half = crop.crop((0, 0, half, crop.height))
    right_half = crop.crop((half, 0, crop.width, crop.height))

    green_left = _green_pixels(left_half)
    green_right = _green_pixels(right_half)
    green_delta = green_right - green_left
    green_threshold = max(150, int((green_left + green_right) * 0.05))
    if green_delta > green_threshold:
        return "outgoing"
    if -green_delta > green_threshold:
        return "incoming"

    edge_left = _edge_energy(left_half)
    edge_right = _edge_energy(right_half)
    edge_threshold = max(1000, int(max(edge_left, edge_right) * 0.15))
    if edge_right - edge_left > edge_threshold:
        return "outgoing"
    if edge_left - edge_right > edge_threshold:
        return "incoming"

    list_center = (list_rect[0] + list_rect[2]) / 2
    item_center = (left + right) / 2
    if item_center > list_center:
        return "outgoing"
    return "incoming"


def _green_pixels(image: Image.Image) -> int:
    return sum(
        1
        for red, green, blue in image.getdata()
        if green > red + 20 and green > blue + 10 and green > 100
    )


def _edge_energy(image: Image.Image) -> int:
    edges = image.convert("L").filter(ImageFilter.FIND_EDGES)
    return sum(edges.getdata())
