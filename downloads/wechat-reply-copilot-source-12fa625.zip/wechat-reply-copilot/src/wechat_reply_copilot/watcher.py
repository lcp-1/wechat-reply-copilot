from __future__ import annotations

import json
import time
from pathlib import Path

from .config import AppConfig
from .draft import DraftError, generate_drafts, reply_plan_messages
from .interactive import show_reply_choice
from .parser import ParsedMessage, ParsedSnapshot, parse_snapshot
from .sender import SendError, fill_reply
from .wechat_uia import connect_wechat, snapshot_window


class WatchError(RuntimeError):
    """Raised when the message watcher cannot start."""


def run_watcher(config: AppConfig, *, mode: str, interval_seconds: float = 3.0) -> None:
    if mode not in {"auto_prepare", "confirm_send"}:
        raise WatchError(f"Unsupported watcher mode: {mode}")

    print("正在监听当前微信聊天。按 Ctrl+C 停止。")
    handled: dict[str, str] = {}
    ignored_non_direct: set[str] = set()
    print("切换聊天后会自动跟随；只要最新一条是对方的消息且我还没有回复，就会处理。")

    try:
        while True:
            parsed = _capture(config)
            current = _latest_incoming_fingerprint(parsed)
            if current is None or not parsed.active_chat:
                if parsed.active_chat:
                    handled.pop(parsed.active_chat, None)
                time.sleep(interval_seconds)
                continue

            target = _latest_incoming(parsed.messages)
            if (
                parsed.chat_kind != "direct"
                or target is None
                or target.sender != parsed.active_chat
            ):
                if parsed.active_chat not in ignored_non_direct:
                    print(f"已忽略非单聊聊天：{parsed.active_chat} ({parsed.chat_kind})")
                    ignored_non_direct.add(parsed.active_chat)
                time.sleep(interval_seconds)
                continue

            ignored_non_direct.discard(parsed.active_chat)
            if handled.get(parsed.active_chat) == current:
                time.sleep(interval_seconds)
                continue

            handled[parsed.active_chat] = current
            _handle_pending_message(config, parsed=parsed, mode=mode)
            time.sleep(interval_seconds)
    except KeyboardInterrupt:
        print("\n监听已停止。")


def _capture(config: AppConfig) -> ParsedSnapshot:
    window = connect_wechat(
        config.wechat_process_name,
        config.wechat_window_title,
    )
    return parse_snapshot(snapshot_window(window, max_nodes=5000))


def _latest_incoming_fingerprint(parsed: ParsedSnapshot) -> str | None:
    latest = _latest_incoming(parsed.messages)
    if latest is None:
        return None
    return "\x1f".join(
        [
            parsed.active_chat or "",
            latest.sender or "",
            latest.content,
        ]
    )


def _latest_incoming(messages: list[ParsedMessage]) -> ParsedMessage | None:
    for message in reversed(messages):
        if not message.content.strip():
            continue
        if message.direction == "incoming":
            return message
        return None
    return None


def _handle_pending_message(
    config: AppConfig,
    *,
    parsed: ParsedSnapshot,
    mode: str,
) -> None:
    target = _latest_incoming(parsed.messages)
    if target is None or not parsed.active_chat:
        return
    if parsed.chat_kind != "direct" or target.sender != parsed.active_chat:
        print(f"跳过非单聊自动处理：{parsed.active_chat} ({parsed.chat_kind})")
        return

    messages = [
        {
            "sender": message.sender,
            "direction": message.direction,
            "content": message.content,
        }
        for message in parsed.messages
    ]
    try:
        result = generate_drafts(
            config,
            conversation_name=parsed.active_chat,
            count=3,
            messages=messages,
        )
    except DraftError as exc:
        print(f"生成草稿失败: {exc}")
        return

    output_path = Path("artifacts/drafts-latest.json")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(
        json.dumps(result, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    pending_count = int(result.get("pending_message_count", 1))
    print(
        f"已结合 {pending_count} 条未回复消息，"
        f"为 {parsed.active_chat} 生成 3 条草稿。"
    )

    if mode == "auto_prepare":
        first_plan = result["drafts"][0]
        plan_messages = reply_plan_messages(first_plan)
        try:
            fill_reply(
                config,
                conversation_name=parsed.active_chat,
                expected_incoming_content=target.content,
                text=plan_messages[0],
            )
        except SendError as exc:
            if exc.reason in {
                "active_chat_changed",
                "no_pending_message",
                "target_changed",
                "non_direct",
            }:
                print(f"跳过已变化或非单聊聊天：{parsed.active_chat}")
                return
            print(f"自动填入失败: {exc}")
            return
        print("已将第一条候选回复填入微信输入框。按 Enter 才会发送。")
        if len(plan_messages) > 1:
            print("完整方案：")
            for index, message in enumerate(plan_messages, start=1):
                print(f"  {index}. {message}")
            print("模式 1 只预填第一条，其余消息不会自动填入或发送。")
        return

    show_reply_choice(
        config,
        conversation_name=parsed.active_chat,
        target_incoming=target.content,
        pending_count=pending_count,
        drafts=result["drafts"],
    )
