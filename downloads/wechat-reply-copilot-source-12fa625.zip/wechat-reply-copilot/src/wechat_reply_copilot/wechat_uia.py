from __future__ import annotations

import time
from dataclasses import dataclass
from pathlib import Path

import win32api
import win32con
import win32gui
import win32process
from pywinauto.controls.uiawrapper import UIAWrapper
from pywinauto.uia_element_info import UIAElementInfo

from .models import UiNode, WindowSnapshot
from .wechat_screen import annotate_message_sides


class WeChatUnavailableError(RuntimeError):
    """Raised when the WeChat window cannot be reached."""


@dataclass(frozen=True)
class WeChatWindow:
    handle: int

    @property
    def element_info(self) -> UIAElementInfo:
        return UIAElementInfo(self.handle)

    def window_text(self) -> str:
        return self.element_info.name

    def restore(self) -> None:
        win32gui.ShowWindow(self.handle, win32con.SW_RESTORE)

    def set_focus(self) -> None:
        self.bring_to_front()
        UIAWrapper(self.element_info).set_focus()

    def bring_to_front(self) -> None:
        self.restore()
        win32gui.SetWindowPos(
            self.handle,
            win32con.HWND_TOPMOST,
            0,
            0,
            0,
            0,
            win32con.SWP_NOMOVE | win32con.SWP_NOSIZE | win32con.SWP_SHOWWINDOW,
        )
        time.sleep(0.2)
        win32gui.SetWindowPos(
            self.handle,
            win32con.HWND_NOTOPMOST,
            0,
            0,
            0,
            0,
            win32con.SWP_NOMOVE | win32con.SWP_NOSIZE | win32con.SWP_SHOWWINDOW,
        )

    def find_element(
        self,
        *,
        control_type: str,
        title: str,
        max_nodes: int = 5000,
    ) -> UIAElementInfo | None:
        stack = [self.element_info]
        visited = 0
        while stack and visited < max_nodes:
            element = stack.pop()
            visited += 1
            if element.control_type == control_type and element.name == title:
                return element
            stack.extend(reversed(_children(element)))
        return None


def connect_wechat(process_name: str, window_title: str) -> WeChatWindow:
    configured_name = Path(process_name).name.casefold()
    process_names = {configured_name, "weixin.exe", "wechat.exe"}
    handle = _find_wechat_handle(process_names, window_title)
    window = WeChatWindow(handle)
    element_info = window.element_info
    if not element_info.name:
        raise WeChatUnavailableError("Could not access the WeChat main window.")
    if element_info.class_name in {"mmui::LoginWindow", "WeChatLoginWndForPC"}:
        raise WeChatUnavailableError("WeChat is showing the login window. Please sign in first.")
    return window


def snapshot_window(
    window: WeChatWindow,
    *,
    max_nodes: int = 5000,
) -> WindowSnapshot:
    root = window.element_info
    nodes: list[UiNode] = []
    stack: list[tuple[UIAElementInfo, int]] = [(root, 0)]

    while stack and len(nodes) < max_nodes:
        element, depth = stack.pop()
        left, top, right, bottom = _rectangle(element)
        nodes.append(
            UiNode(
                depth=depth,
                control_type=_control_type(element),
                name=_element_name(element),
                automation_id=_automation_id(element),
                class_name=_class_name(element),
                left=left,
                top=top,
                right=right,
                bottom=bottom,
            )
        )

        children = _children(element)
        for child in reversed(children):
            stack.append((child, depth + 1))

    process_path = _process_path(root)
    if len(nodes) <= 2 and _class_name(root) == "Qt51514QWindowIcon":
        raise WeChatUnavailableError(
            "新版微信主窗口未向 UI Automation 暴露聊天控件。"
            "当前版本无法读取微信 4.x，需要回退微信 3.9.x，"
            "或改用本地 OCR 读取方案。"
        )
    if _class_name(root) == "mmui::MainWindow":
        annotate_message_sides(nodes, window.handle)
    return WindowSnapshot.create(
        window_title=_element_name(root) or window.window_text(),
        process_path=process_path,
        nodes=nodes,
    )


def _find_wechat_handle(process_names: set[str], window_title: str) -> int:
    handles: list[tuple[int, str, str, bool, int]] = []

    def collect(handle: int, _: object) -> bool:
        title = win32gui.GetWindowText(handle)
        class_name = win32gui.GetClassName(handle)
        visible = bool(win32gui.IsWindowVisible(handle))
        if not visible or not title:
            return True
        if window_title and title != window_title:
            return True
        if not window_title and title not in {"微信", "WeChat", "Weixin"}:
            return True
        if any(part in class_name for part in ("Tray", "SystemMessage", "IME", "GDI")):
            return True

        _, process_id = win32process.GetWindowThreadProcessId(handle)
        process_path = _process_path_from_id(process_id)
        if Path(process_path).name.casefold() not in process_names:
            return True
        rect = win32gui.GetWindowRect(handle)
        area = max(0, rect[2] - rect[0]) * max(0, rect[3] - rect[1])
        handles.append((handle, title, class_name, visible, area))
        return True

    win32gui.EnumWindows(collect, None)
    if not handles:
        raise WeChatUnavailableError(
            "Could not find a visible Weixin/WeChat window. Open WeChat and sign in first."
        )
    return max(handles, key=lambda item: item[4])[0]


def _process_path_from_id(process_id: int) -> str:
    process_handle = win32api.OpenProcess(0x1000, False, process_id)
    if not process_handle:
        return ""
    try:
        return str(win32process.GetModuleFileNameEx(process_handle, 0))
    except Exception:
        return ""
    finally:
        win32api.CloseHandle(process_handle)


def _children(element: UIAElementInfo) -> list[UIAElementInfo]:
    try:
        return list(element.children())
    except Exception:
        return []


def _element_name(element: UIAElementInfo) -> str:
    try:
        return (element.name or "").strip()
    except Exception:
        return ""


def _control_type(element: UIAElementInfo) -> str:
    try:
        return str(element.control_type or "").strip()
    except Exception:
        return ""


def _automation_id(element: UIAElementInfo) -> str:
    try:
        return str(element.automation_id or "").strip()
    except Exception:
        return ""


def _class_name(element: UIAElementInfo) -> str:
    try:
        return str(element.class_name or "").strip()
    except Exception:
        return ""


def _process_path(element: UIAElementInfo) -> str:
    try:
        return str(element.process_path or "").strip()
    except Exception:
        return ""


def _rectangle(element: UIAElementInfo) -> tuple[int, int, int, int]:
    try:
        rectangle = element.rectangle
        return rectangle.left, rectangle.top, rectangle.right, rectangle.bottom
    except Exception:
        return 0, 0, 0, 0
