from __future__ import annotations

from dataclasses import dataclass

import httpx

from .config import AppConfig
from .secrets_store import SecretStoreError, load_api_key


class LlmError(RuntimeError):
    """Raised when the configured cloud API cannot return a completion."""


@dataclass(frozen=True)
class ChatMessage:
    role: str
    content: str


def chat_completion(
    config: AppConfig,
    messages: list[ChatMessage],
    *,
    temperature: float = 0.3,
) -> str:
    provider = config.provider
    if not provider.model:
        raise LlmError("No provider model is configured.")

    try:
        api_key = load_api_key(provider)
    except SecretStoreError as exc:
        raise LlmError(str(exc)) from exc
    if not api_key:
        raise LlmError("No API key is configured. Run `wrc configure` or `wrc set-key`.")

    endpoint = f"{provider.base_url}/chat/completions"
    payload = {
        "model": provider.model,
        "messages": [{"role": message.role, "content": message.content} for message in messages],
        "temperature": temperature,
    }
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }

    try:
        response = httpx.post(
            endpoint,
            headers=headers,
            json=payload,
            timeout=provider.timeout_seconds,
        )
    except httpx.HTTPError as exc:
        raise LlmError(f"Cloud API request failed: {exc}") from exc

    if response.status_code >= 400:
        detail = response.text.strip()
        if len(detail) > 1000:
            detail = detail[:1000] + "..."
        raise LlmError(f"Cloud API returned HTTP {response.status_code}: {detail}")

    try:
        data = response.json()
        content = data["choices"][0]["message"]["content"]
    except (KeyError, IndexError, TypeError, ValueError) as exc:
        raise LlmError("Cloud API returned an unexpected response shape.") from exc

    if not isinstance(content, str) or not content.strip():
        raise LlmError("Cloud API returned an empty completion.")
    return content.strip()


def test_connection(config: AppConfig) -> str:
    return chat_completion(
        config,
        [
            ChatMessage(
                role="system",
                content="You are a connectivity test. Answer with exactly: OK",
            ),
            ChatMessage(role="user", content="Connectivity test."),
        ],
        temperature=0,
    )
