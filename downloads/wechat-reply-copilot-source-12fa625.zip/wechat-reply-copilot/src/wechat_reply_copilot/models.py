from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from typing import Any


@dataclass(frozen=True)
class UiNode:
    depth: int
    control_type: str
    name: str
    automation_id: str = ""
    class_name: str = ""
    left: int = 0
    top: int = 0
    right: int = 0
    bottom: int = 0
    horizontal_side: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class WindowSnapshot:
    window_title: str
    process_path: str
    captured_at: str
    nodes: list[UiNode]

    @classmethod
    def create(
        cls,
        *,
        window_title: str,
        process_path: str,
        nodes: list[UiNode],
    ) -> WindowSnapshot:
        return cls(
            window_title=window_title,
            process_path=process_path,
            captured_at=datetime.now(UTC).isoformat(),
            nodes=nodes,
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "window_title": self.window_title,
            "process_path": self.process_path,
            "captured_at": self.captured_at,
            "nodes": [node.to_dict() for node in self.nodes],
        }
