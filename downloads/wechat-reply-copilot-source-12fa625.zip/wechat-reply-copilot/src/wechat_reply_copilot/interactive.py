from __future__ import annotations

import tkinter as tk
from tkinter import messagebox

from .config import AppConfig
from .draft import reply_plan_messages
from .sender import SendError, send_reply_sequence


def show_reply_choice(
    config: AppConfig,
    *,
    conversation_name: str,
    target_incoming: str,
    pending_count: int = 1,
    drafts: list[dict[str, object]],
) -> None:
    root = tk.Tk()
    root.title("WeChat Reply Copilot")
    root.attributes("-topmost", True)
    root.resizable(False, False)

    frame = tk.Frame(root, padx=16, pady=14)
    frame.pack(fill="both", expand=True)

    tk.Label(
        frame,
        text=f"回复 {conversation_name}",
        font=("Microsoft YaHei UI", 13, "bold"),
        anchor="w",
    ).pack(fill="x")
    pending_label = (
        f"对方（{pending_count} 条未回复）"
        if pending_count > 1
        else "对方"
    )
    tk.Label(
        frame,
        text=f"{pending_label}：{target_incoming}",
        wraplength=520,
        justify="left",
        anchor="w",
    ).pack(fill="x", pady=(6, 12))

    def choose(draft: dict[str, object]) -> None:
        messages = reply_plan_messages(draft)
        preview = "\n".join(f"{index}. {text}" for index, text in enumerate(messages, 1))
        send_hint = (
            f"将连续发送 {len(messages)} 条消息："
            if len(messages) > 1
            else "将发送："
        )
        confirmed = messagebox.askyesno(
            "确认发送",
            f"发送给 {conversation_name}？\n\n{send_hint}\n{preview}",
            parent=root,
        )
        if not confirmed:
            return
        try:
            send_reply_sequence(
                config,
                conversation_name=conversation_name,
                expected_incoming_content=target_incoming,
                messages=messages,
            )
        except SendError as exc:
            messagebox.showerror("发送已取消", str(exc), parent=root)
            return
        messagebox.showinfo(
            "已发送",
            f"{len(messages)} 条回复已按顺序发送并完成验证。",
            parent=root,
        )
        root.destroy()

    for index, draft in enumerate(drafts, start=1):
        label = draft.get("label") or f"回复 {index}"
        messages = reply_plan_messages(draft)
        preview = "\n".join(
            f"   {message_index}. {text}"
            for message_index, text in enumerate(messages, 1)
        )
        tk.Button(
            frame,
            text=f"{index}. {label}\n{preview}",
            wraplength=520,
            justify="left",
            anchor="w",
            padx=10,
            pady=8,
            command=lambda item=draft: choose(item),
        ).pack(fill="x", pady=4)

    controls = tk.Frame(frame)
    controls.pack(fill="x", pady=(12, 0))
    tk.Button(controls, text="忽略", width=10, command=root.destroy).pack(side="right")
    root.mainloop()
