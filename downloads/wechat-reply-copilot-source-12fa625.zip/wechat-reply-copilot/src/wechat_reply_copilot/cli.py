from __future__ import annotations

import argparse
import getpass
import json
import sys
from pathlib import Path

from . import __version__
from .config import (
    AppConfig,
    ProviderConfig,
    default_config_path,
    load_config,
    render_config,
    write_config,
)
from .draft import DraftError, generate_drafts
from .llm import LlmError, test_connection
from .models import UiNode, WindowSnapshot
from .parser import ConversationSummary, ParsedMessage, ParsedSnapshot, parse_snapshot
from .secrets_store import (
    SecretStoreError,
    api_key_source,
    delete_api_key,
    store_api_key,
)
from .storage import (
    database_summary,
    initialize_database,
    load_style_profile,
    style_stats,
    sync_parsed_snapshot,
)
from .style import StyleProfileError, build_style_profile
from .watcher import run_watcher
from .wechat_uia import WeChatUnavailableError, connect_wechat, snapshot_window


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="wrc",
        description="Read-only WeChat reply drafting assistant",
    )
    parser.add_argument("--version", action="version", version=__version__)
    parser.add_argument("--config", type=Path, default=None, help="Path to config.toml")

    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("menu", help="Open the guided interactive menu")

    configure_parser = commands.add_parser(
        "configure",
        help="Write provider settings and store the API key in Windows Credential Manager",
    )
    configure_parser.add_argument("--name", default="deepseek")
    configure_parser.add_argument("--base-url", default="https://api.deepseek.com")
    configure_parser.add_argument("--model", default="deepseek-flash")
    configure_parser.add_argument("--api-key-env", default="DEEPSEEK_API_KEY")
    configure_parser.add_argument(
        "--skip-key",
        action="store_true",
        help="Update provider settings without prompting for an API key",
    )
    configure_parser.add_argument(
        "--yes",
        action="store_true",
        help="Use the supplied provider values without interactive prompts",
    )

    set_key_parser = commands.add_parser(
        "set-key",
        help="Store or replace the provider API key",
    )
    set_key_parser.set_defaults(api_key_env="DEEPSEEK_API_KEY")

    commands.add_parser("delete-key", help="Delete the stored API key")
    commands.add_parser("key-status", help="Show where the API key is loaded from")
    commands.add_parser("test-api", help="Send a minimal connectivity request to the API")

    inspect_parser = commands.add_parser("inspect", help="Inspect the visible WeChat UI")
    inspect_parser.add_argument(
        "--json",
        action="store_true",
        help="Print the full snapshot as JSON",
    )
    inspect_parser.add_argument(
        "--save",
        type=Path,
        default=None,
        help="Write the snapshot JSON to this path",
    )
    inspect_parser.add_argument(
        "--max-nodes",
        type=int,
        default=5000,
        help="Maximum UI Automation nodes to inspect",
    )

    parse_parser = commands.add_parser(
        "parse",
        help="Parse the visible WeChat UI into conversations and messages",
    )
    parse_parser.add_argument(
        "--input",
        type=Path,
        default=None,
        help="Read a previously saved inspect JSON instead of capturing WeChat now",
    )
    parse_parser.add_argument(
        "--save",
        type=Path,
        default=None,
        help="Write the parsed JSON to this path",
    )
    parse_parser.add_argument(
        "--json",
        action="store_true",
        help="Print the full parsed JSON",
    )

    sync_parser = commands.add_parser(
        "sync",
        help="Store parsed messages and outgoing style samples in SQLite",
    )
    sync_parser.add_argument(
        "--input",
        type=Path,
        default=Path("artifacts/parsed-latest.json"),
        help="Parsed JSON file to import",
    )

    style_parser = commands.add_parser(
        "style-stats",
        help="Show locally collected style sample counts",
    )
    style_parser.add_argument(
        "--conversation",
        default=None,
        help="Show a specific conversation summary",
    )

    build_style_parser = commands.add_parser(
        "build-style",
        help="Generate and store a global or conversation style profile",
    )
    build_style_parser.add_argument(
        "--scope",
        choices=["global", "conversation"],
        default="global",
    )
    build_style_parser.add_argument("--conversation", default=None)

    style_show_parser = commands.add_parser(
        "style-show",
        help="Show a stored style profile",
    )
    style_show_parser.add_argument(
        "--scope",
        choices=["global", "conversation"],
        default="global",
    )
    style_show_parser.add_argument("--conversation", default=None)

    draft_parser = commands.add_parser(
        "draft",
        help="Generate candidate replies for the latest synced conversation",
    )
    draft_parser.add_argument("--conversation", default=None)
    draft_parser.add_argument("--count", type=int, default=3)
    draft_parser.add_argument(
        "--save",
        type=Path,
        default=None,
        help="Write the generated drafts to this path",
    )

    commands.add_parser("init-db", help="Initialize the local SQLite database")
    commands.add_parser("paths", help="Show resolved application paths")
    commands.add_parser("init-config", help="Print a default config.toml")
    return parser


def main(argv: list[str] | None = None) -> int:
    _configure_console()
    args = build_parser().parse_args(argv)

    if args.command == "init-config":
        print(render_config(ProviderConfig()), end="")
        return 0

    config_path = args.config or default_config_path()
    config: AppConfig = load_config(config_path)

    if args.command == "menu":
        return menu_command(config, config_path)

    if args.command == "configure":
        return configure_command(args, config, config_path)

    if args.command == "set-key":
        return set_key_command(config.provider)

    if args.command == "delete-key":
        try:
            delete_api_key(config.provider)
        except SecretStoreError as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 2
        print("Stored API key deleted.")
        return 0

    if args.command == "key-status":
        try:
            source = api_key_source(config.provider)
        except SecretStoreError as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 2
        print(
            json.dumps(
                {
                    "provider": config.provider.name,
                    "base_url": config.provider.base_url,
                    "model": config.provider.model,
                    "api_key_source": source,
                },
                indent=2,
            )
        )
        return 0

    if args.command == "test-api":
        try:
            response = test_connection(config)
        except LlmError as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 2
        print(response)
        return 0

    if args.command == "paths":
        print(
            json.dumps(
                {
                    "config": str(config_path),
                    "database": str(config.database_path),
                },
                indent=2,
            )
        )
        return 0

    if args.command == "init-db":
        initialize_database(config.database_path)
        print(json.dumps(database_summary(config.database_path), indent=2))
        return 0

    if args.command == "inspect":
        return inspect_command(args, config)

    if args.command == "parse":
        return parse_command(args, config)

    if args.command == "sync":
        if not args.input.exists():
            print(f"error: parsed file not found: {args.input}", file=sys.stderr)
            return 2
        parsed = _parsed_from_dict(json.loads(args.input.read_text(encoding="utf-8")))
        result = sync_parsed_snapshot(config.database_path, parsed)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0

    if args.command == "style-stats":
        result = style_stats(config.database_path, args.conversation)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0

    if args.command == "build-style":
        try:
            result = build_style_profile(
                config,
                scope=args.scope,
                conversation_name=args.conversation,
            )
        except StyleProfileError as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 2
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0

    if args.command == "style-show":
        try:
            result = load_style_profile(
                config.database_path,
                scope=args.scope,
                conversation_name=args.conversation,
            )
        except ValueError as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 2
        if result is None:
            print("No stored style profile.")
            return 1
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0

    if args.command == "draft":
        try:
            result = generate_drafts(
                config,
                conversation_name=args.conversation,
                count=max(1, min(args.count, 5)),
            )
        except DraftError as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 2
        if args.save:
            args.save.parent.mkdir(parents=True, exist_ok=True)
            args.save.write_text(
                json.dumps(result, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0

    raise AssertionError(f"Unhandled command: {args.command}")


def _configure_console() -> None:
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if not callable(reconfigure):
            continue
        try:
            reconfigure(errors="replace")
        except (OSError, ValueError):
            continue


def configure_command(
    args: argparse.Namespace,
    config: AppConfig,
    config_path: Path,
) -> int:
    provider = config.provider
    if sys.stdin.isatty() and not args.yes:
        name = _prompt("Provider name", args.name or provider.name)
        base_url = _prompt("Base URL", args.base_url or provider.base_url)
        model = _prompt("Model", args.model or provider.model)
        api_key_env = args.api_key_env or provider.api_key_env
    else:
        name = args.name or provider.name
        base_url = args.base_url or provider.base_url
        model = args.model or provider.model
        api_key_env = args.api_key_env or provider.api_key_env

    updated = ProviderConfig(
        name=name,
        base_url=base_url.rstrip("/"),
        model=model,
        api_key_env=api_key_env,
        keyring_service=provider.keyring_service,
        keyring_username=name,
        timeout_seconds=provider.timeout_seconds,
    )
    write_config(config_path, updated)
    print(f"Configuration written to: {config_path}")

    if args.skip_key:
        return 0

    if not sys.stdin.isatty():
        print("API key was not set because stdin is not interactive.")
        print("Run `wrc set-key` from a terminal to enter it securely.")
        return 0

    provided = getpass.getpass("DeepSeek API key (leave empty to keep current): ").strip()
    if not provided:
        print("API key unchanged.")
        return 0

    try:
        store_api_key(updated, provided)
    except SecretStoreError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    print("API key stored in Windows Credential Manager.")
    return 0


def set_key_command(provider: ProviderConfig) -> int:
    if not sys.stdin.isatty():
        print(
            "error: `wrc set-key` must be run from an interactive terminal.",
            file=sys.stderr,
        )
        return 2
    provided = getpass.getpass("DeepSeek API key: ").strip()
    try:
        store_api_key(provider, provided)
    except SecretStoreError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    print("API key stored in Windows Credential Manager.")
    return 0


def inspect_command(args: argparse.Namespace, config: AppConfig) -> int:
    try:
        window = connect_wechat(
            config.wechat_process_name,
            config.wechat_window_title,
        )
        snapshot = snapshot_window(window, max_nodes=args.max_nodes)
    except WeChatUnavailableError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2

    snapshot_dict = snapshot.to_dict()
    if args.save:
        args.save.parent.mkdir(parents=True, exist_ok=True)
        args.save.write_text(
            json.dumps(snapshot_dict, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    if args.json:
        print(json.dumps(snapshot_dict, ensure_ascii=False, indent=2))
        return 0

    print(f"Window: {snapshot.window_title}")
    print(f"Process: {snapshot.process_path}")
    print(f"Nodes: {len(snapshot.nodes)}")
    for node in snapshot.nodes:
        if not node.name:
            continue
        indent = "  " * node.depth
        print(f"{indent}{node.control_type}: {node.name}")
    return 0


def parse_command(args: argparse.Namespace, config: AppConfig) -> int:
    if args.input:
        raw = json.loads(args.input.read_text(encoding="utf-8"))
        snapshot = _snapshot_from_dict(raw)
    else:
        try:
            window = connect_wechat(
                config.wechat_process_name,
                config.wechat_window_title,
            )
            snapshot = snapshot_window(window, max_nodes=5000)
        except WeChatUnavailableError as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 2

    parsed = parse_snapshot(snapshot)
    parsed_dict = parsed.to_dict()
    if args.save:
        args.save.parent.mkdir(parents=True, exist_ok=True)
        args.save.write_text(
            json.dumps(parsed_dict, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    if args.json:
        print(json.dumps(parsed_dict, ensure_ascii=False, indent=2))
        return 0

    print(f"Current user: {parsed.current_user or 'unknown'}")
    print(f"Active chat: {parsed.active_chat or 'unknown'}")
    print(f"Conversations: {len(parsed.conversations)}")
    for conversation in parsed.conversations:
        suffix = f" | {conversation.last_message_time}" if conversation.last_message_time else ""
        print(f"- {conversation.display_name}{suffix}")
    print(f"Visible messages: {len(parsed.messages)}")
    for message in parsed.messages:
        sender = message.sender or message.direction
        print(f"[{message.direction}] {sender}: {message.content}")
    return 0


def _snapshot_from_dict(raw: dict) -> WindowSnapshot:
    return WindowSnapshot(
        window_title=str(raw.get("window_title", "")),
        process_path=str(raw.get("process_path", "")),
        captured_at=str(raw.get("captured_at", "")),
        nodes=[
            UiNode(
                depth=int(node.get("depth", 0)),
                control_type=str(node.get("control_type", "")),
                name=str(node.get("name", "")),
                automation_id=str(node.get("automation_id", "")),
                class_name=str(node.get("class_name", "")),
            )
            for node in raw.get("nodes", [])
        ],
    )


def _parsed_from_dict(raw: dict) -> ParsedSnapshot:
    return ParsedSnapshot(
        active_chat=raw.get("active_chat"),
        current_user=raw.get("current_user"),
        chat_kind=str(raw.get("chat_kind", "unknown")),
        conversations=[
            ConversationSummary(
                display_name=str(item.get("display_name", "")),
                last_message_time=item.get("last_message_time"),
                last_message_preview=item.get("last_message_preview"),
            )
            for item in raw.get("conversations", [])
        ],
        messages=[
            ParsedMessage(
                sender=item.get("sender"),
                direction=str(item.get("direction", "unknown")),
                content=str(item.get("content", "")),
            )
            for item in raw.get("messages", [])
        ],
    )


def _prompt(label: str, default: str) -> str:
    value = input(f"{label} [{default}]: ").strip()
    return value or default


def menu_command(config: AppConfig, config_path: Path) -> int:
    if not sys.stdin.isatty():
        print("error: The menu must be run from an interactive terminal.", file=sys.stderr)
        return 2

    actions = {
        "1": ("测试 API 连接", lambda: _menu_test_api(config)),
        "2": ("收集当前微信聊天", lambda: _menu_collect_current_chat(config)),
        "3": ("查看已积累样本", lambda: _menu_style_stats(config)),
        "4": ("更新全局风格", lambda: _menu_build_style(config, "global", None)),
        "5": ("更新联系人风格", lambda: _menu_build_contact_style(config)),
        "6": ("回复模式", lambda: _menu_reply_modes(config)),
        "7": ("查看最近草稿", lambda: _menu_show_latest_drafts(config)),
        "8": ("修改 API 配置", lambda: _menu_configure(config, config_path)),
        "9": ("修改 API Key", lambda: set_key_command(config.provider)),
        "10": ("查看配置和数据库路径", lambda: _menu_show_paths(config, config_path)),
    }

    while True:
        print()
        print("WeChat Reply Copilot")
        print("====================")
        for key, (label, _) in actions.items():
            print(f"{key}. {label}")
        print("0. 退出")
        choice = input("请选择: ").strip()
        if choice == "0":
            return 0
        action = actions.get(choice)
        if action is None:
            print("无效选项。")
            continue

        print()
        try:
            action[1]()
        except KeyboardInterrupt:
            print("\n操作已取消。")
        except Exception as exc:
            print(f"操作失败: {exc}")
        input("按回车返回菜单...")


def _menu_test_api(config: AppConfig) -> None:
    try:
        source = api_key_source(config.provider)
    except SecretStoreError:
        source = "unavailable"
    print(f"API Key 来源: {source}")
    print(test_connection(config))


def _menu_collect_current_chat(config: AppConfig) -> None:
    _, result = _capture_and_sync_current_chat(config)
    print(f"当前聊天: {result['conversation']}")
    print(f"新增消息: {result['inserted_messages']}")
    print(f"新增风格样本: {result['inserted_style_samples']}")
    print("如果还要继续收集，请在微信中向上滚动，然后再次选择 2。")


def _capture_and_sync_current_chat(
    config: AppConfig,
) -> tuple[ParsedSnapshot, dict[str, int | str]]:
    snapshot_path = Path("artifacts/inspect-latest.json")
    parsed_path = Path("artifacts/parsed-latest.json")
    window = connect_wechat(
        config.wechat_process_name,
        config.wechat_window_title,
    )
    snapshot = snapshot_window(window, max_nodes=5000)
    snapshot_path.parent.mkdir(parents=True, exist_ok=True)
    snapshot_path.write_text(
        json.dumps(snapshot.to_dict(), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    parsed = parse_snapshot(snapshot)
    parsed_path.write_text(
        json.dumps(parsed.to_dict(), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    result = sync_parsed_snapshot(config.database_path, parsed)
    return parsed, result


def _menu_style_stats(config: AppConfig) -> None:
    result = style_stats(config.database_path)
    print(f"全局风格样本: {result['global_samples']}")
    for item in result["conversation_stats"]:
        print(
            f"- {item['conversation']}: 上下文 {item['messages']} 条 "
            f"(对方 {item['incoming_messages']}，我 {item['outgoing_messages']}，"
            f"未知 {item['unknown_messages']})，"
            f"风格样本 {item['samples']} 条，平均 {item['average_characters']} 字"
        )


def _menu_build_style(
    config: AppConfig,
    scope: str,
    conversation_name: str | None,
) -> None:
    result = build_style_profile(
        config,
        scope=scope,
        conversation_name=conversation_name,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))


def _menu_build_contact_style(config: AppConfig) -> None:
    conversation_name = input("联系人/群名称: ").strip()
    if not conversation_name:
        print("未输入名称。")
        return
    _menu_build_style(config, "conversation", conversation_name)


def _menu_generate_drafts(config: AppConfig) -> None:
    parsed, _ = _capture_and_sync_current_chat(config)
    if not parsed.active_chat:
        raise DraftError("无法识别当前打开的聊天。")
    if parsed.chat_kind != "direct":
        print(f"跳过非单聊回复：{parsed.active_chat} ({parsed.chat_kind})")
        return
    messages = [
        {
            "sender": message.sender,
            "direction": message.direction,
            "content": message.content,
        }
        for message in parsed.messages
    ]
    result = generate_drafts(
        config,
        conversation_name=parsed.active_chat,
        count=3,
        messages=messages,
    )
    output_path = Path("artifacts/drafts-latest.json")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(
        json.dumps(result, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(f"当前聊天: {result['conversation']}")
    print(f"待回复消息: {result['pending_message_count']} 条")
    print(f"参考背景: {result['context_message_count']} 条")
    print(f"最后一条待回复: {result['target_message']}")
    style_sources = result.get("style_sources", {})
    print(
        "风格来源: "
        f"全局={'是' if style_sources.get('global_profile') else '否'}，"
        f"联系人={'是' if style_sources.get('conversation_profile') else '否'}"
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))


def _menu_reply_modes(config: AppConfig) -> None:
    while True:
        print()
        print("回复模式")
        print("1. 自动监听并预填首条，不发送")
        print("2. 监听并选择发送")
        print("3. 手动生成草稿，不发送")
        print("0. 返回")
        choice = input("请选择: ").strip()
        if choice == "0":
            return
        if choice == "1":
            run_watcher(config, mode="auto_prepare")
            return
        if choice == "2":
            run_watcher(config, mode="confirm_send")
            return
        if choice == "3":
            _menu_generate_drafts(config)
            return
        print("无效选项。")


def _menu_show_latest_drafts(config: AppConfig) -> None:
    del config
    output_path = Path("artifacts/drafts-latest.json")
    if not output_path.exists():
        print("还没有生成过草稿。")
        return
    print(output_path.read_text(encoding="utf-8"))


def _menu_configure(config: AppConfig, config_path: Path) -> None:
    args = argparse.Namespace(
        name=config.provider.name,
        base_url=config.provider.base_url,
        model=config.provider.model,
        api_key_env=config.provider.api_key_env,
        skip_key=False,
        yes=False,
    )
    configure_command(args, config, config_path)


def _menu_show_paths(config: AppConfig, config_path: Path) -> None:
    print(f"配置文件: {config_path}")
    print(f"数据库: {config.database_path}")


if __name__ == "__main__":
    raise SystemExit(main())
