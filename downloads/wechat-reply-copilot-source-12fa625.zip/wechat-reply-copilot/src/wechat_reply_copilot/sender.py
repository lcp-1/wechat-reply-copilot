from __future__ import annotations

import time
from contextlib import suppress

import win32api
import win32con
from pywinauto.controls.uiawrapper import UIAWrapper
from pywinauto.keyboard import KeyAction

from .config import AppConfig
from .parser import ParsedSnapshot, parse_snapshot
from .wechat_uia import connect_wechat, snapshot_window


class SendError(RuntimeError):
    """Raised when a reply cannot be sent safely."""

    def __init__(self, message: str, *, reason: str = "blocked") -> None:
        super().__init__(message)
        self.reason = reason


def send_reply(
    config: AppConfig,
    *,
    conversation_name: str,
    expected_incoming_content: str,
    text: str,
    dry_run: bool = False,
) -> dict[str, object]:
    return send_reply_sequence(
        config,
        conversation_name=conversation_name,
        expected_incoming_content=expected_incoming_content,
        messages=[text],
        dry_run=dry_run,
    )


def send_reply_sequence(
    config: AppConfig,
    *,
    conversation_name: str,
    expected_incoming_content: str,
    messages: list[str],
    dry_run: bool = False,
) -> dict[str, object]:
    reply_messages = _normalize_reply_messages(messages)
    edit = prepare_reply(
        config,
        conversation_name=conversation_name,
        expected_incoming_content=expected_incoming_content,
        text=reply_messages[0],
        dry_run=dry_run,
    )
    if dry_run:
        return {
            "sent": False,
            "dry_run": True,
            "conversation": conversation_name,
            "messages": reply_messages,
        }

    sent_messages: list[str] = []
    for index, text in enumerate(reply_messages):
        if index > 0:
            edit = _prepare_follow_up(
                config,
                conversation_name=conversation_name,
                text=text,
            )
        edit.type_keys("{ENTER}")
        _wait_for_outgoing(
            config,
            conversation_name=conversation_name,
            text=text,
        )
        sent_messages.append(text)

    return {
        "sent": True,
        "dry_run": False,
        "conversation": conversation_name,
        "messages": sent_messages,
    }


def fill_reply(
    config: AppConfig,
    *,
    conversation_name: str,
    expected_incoming_content: str,
    text: str,
) -> dict[str, object]:
    prepare_reply(
        config,
        conversation_name=conversation_name,
        expected_incoming_content=expected_incoming_content,
        text=text,
        dry_run=False,
    )
    return {
        "sent": False,
        "filled": True,
        "conversation": conversation_name,
        "text": text,
    }


def prepare_reply(
    config: AppConfig,
    *,
    conversation_name: str,
    expected_incoming_content: str,
    text: str,
    dry_run: bool = False,
):
    if not text.strip():
        raise SendError("Reply text cannot be empty.")

    window = connect_wechat(
        config.wechat_process_name,
        config.wechat_window_title,
    )
    parsed = parse_snapshot(snapshot_window(window, max_nodes=5000))
    _validate_target(
        parsed,
        conversation_name=conversation_name,
        expected_incoming_content=expected_incoming_content,
        text=text,
    )

    edit = _get_input_edit(window, conversation_name=conversation_name)
    _ensure_edit_empty(edit)

    if dry_run:
        return edit

    _write_edit_text(edit, text)
    return edit


def _prepare_follow_up(
    config: AppConfig,
    *,
    conversation_name: str,
    text: str,
):
    window = connect_wechat(
        config.wechat_process_name,
        config.wechat_window_title,
    )
    parsed = parse_snapshot(snapshot_window(window, max_nodes=5000))
    if parsed.active_chat != conversation_name:
        raise SendError(
            f"Active chat changed while sending: expected {conversation_name!r}, "
            f"found {parsed.active_chat!r}.",
            reason="active_chat_changed",
        )
    if parsed.chat_kind != "direct":
        raise SendError(
            "Multi-message sending was cancelled because the chat is not a direct chat.",
            reason="non_direct",
        )

    visible = [message for message in parsed.messages if message.content.strip()]
    if not visible or visible[-1].direction != "outgoing":
        raise SendError(
            "A new incoming message arrived before the next planned reply; "
            "the remaining messages were not sent.",
            reason="target_changed",
        )

    edit = _get_input_edit(window, conversation_name=conversation_name)
    _ensure_edit_empty(edit)
    _write_edit_text(edit, text)
    return edit


def _get_input_edit(window, *, conversation_name: str):
    edit_info = window.find_element(control_type="Edit", title=conversation_name)
    if edit_info is None:
        raise SendError("Could not find the WeChat message input box.")
    edit = UIAWrapper(edit_info)
    _focus_edit(window, edit)
    return edit


def _ensure_edit_empty(edit) -> None:
    existing = str(edit.get_value() or "")
    if existing.strip():
        raise SendError("The WeChat input box is not empty; sending was cancelled.")


def _focus_edit(window, edit, *, timeout_seconds: float = 1.5) -> None:
    try:
        window.set_focus()
    except Exception as exc:
        raise SendError(f"Could not focus the WeChat window: {exc}") from exc

    deadline = time.monotonic() + timeout_seconds
    last_error: Exception | None = None
    clicked = False
    while time.monotonic() < deadline:
        try:
            edit.set_focus()
            if edit.has_keyboard_focus():
                return
            if not clicked:
                _click_control(edit)
                clicked = True
        except Exception as exc:
            last_error = exc
        time.sleep(0.1)

    detail = f": {last_error}" if last_error else ""
    raise SendError(
        "The WeChat message input box did not receive keyboard focus"
        f" within {timeout_seconds:.1f}s{detail}."
    )


def _click_control(control) -> None:
    rectangle = control.rectangle()
    point = (
        int((rectangle.left + rectangle.right) / 2),
        int((rectangle.top + rectangle.bottom) / 2),
    )
    win32api.SetCursorPos(point)
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0)
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)


def _write_edit_text(edit, text: str, *, timeout_seconds: float = 1.5) -> None:
    if "\r" in text or "\n" in text:
        raise SendError("Reply text contains a line break; sending was cancelled.")

    try:
        encoded = text.encode("utf-16-le")
        for index in range(0, len(encoded), 2):
            unit = int.from_bytes(encoded[index : index + 2], "little")
            KeyAction(chr(unit)).run()
            time.sleep(0.005)
    except Exception as exc:
        _clear_edit(edit)
        raise SendError(f"Could not write the reply into WeChat: {exc}") from exc

    deadline = time.monotonic() + timeout_seconds
    while time.monotonic() < deadline:
        if str(edit.get_value() or "") == text:
            return
        time.sleep(0.05)

    _clear_edit(edit)
    raise SendError(
        "The reply text was not written correctly; sending was cancelled."
    )


def _normalize_reply_messages(messages: list[str]) -> list[str]:
    normalized: list[str] = []
    for message in messages:
        for line in str(message).splitlines():
            text = line.strip()
            if text:
                normalized.append(text)
    if not normalized:
        raise SendError("Reply text cannot be empty.")
    return normalized[:3]


def _clear_edit(edit) -> None:
    with suppress(Exception):
        edit.type_keys("^a{BACKSPACE}")


def _validate_target(
    parsed: ParsedSnapshot,
    *,
    conversation_name: str,
    expected_incoming_content: str,
    text: str,
) -> None:
    if parsed.active_chat != conversation_name:
        raise SendError(
            f"Active chat changed: expected {conversation_name!r}, "
            f"found {parsed.active_chat!r}.",
            reason="active_chat_changed",
        )

    visible = [message for message in parsed.messages if message.content.strip()]
    if not visible:
        raise SendError(
            "No visible messages were found in the active chat.",
            reason="no_pending_message",
        )

    latest_incoming_index = next(
        (
            index
            for index in range(len(visible) - 1, -1, -1)
            if visible[index].direction == "incoming"
        ),
        None,
    )
    if latest_incoming_index is None:
        raise SendError(
            "No pending incoming message was found in the active chat.",
            reason="no_pending_message",
        )

    latest_incoming = visible[latest_incoming_index]
    if latest_incoming.sender != conversation_name:
        raise SendError(
            "Automatic sending is limited to direct messages whose sender matches "
            "the active conversation.",
            reason="non_direct",
        )

    expected_content = expected_incoming_content.strip()
    target_index = next(
        (
            index
            for index in range(len(visible) - 1, -1, -1)
            if visible[index].direction == "incoming"
            and visible[index].sender == conversation_name
            and visible[index].content.strip() == expected_content
        ),
        None,
    )
    if target_index is None:
        raise SendError(
            "The incoming message being answered is no longer visible; "
            "sending was cancelled.",
            reason="target_changed",
        )
    if target_index != latest_incoming_index:
        raise SendError(
            "A newer incoming message arrived after the draft was generated; "
            "sending was cancelled.",
            reason="target_changed",
        )

    if text in [message.content for message in visible if message.direction == "outgoing"]:
        raise SendError(
            "This reply already appears in the recent outgoing messages.",
            reason="duplicate",
        )


def _contains_recent_outgoing(parsed: ParsedSnapshot, text: str) -> bool:
    return any(
        message.direction == "outgoing" and message.content.strip() == text.strip()
        for message in parsed.messages[-5:]
    )


def _wait_for_outgoing(
    config: AppConfig,
    *,
    conversation_name: str,
    text: str,
    timeout_seconds: float = 3.0,
) -> None:
    deadline = time.monotonic() + timeout_seconds
    while time.monotonic() < deadline:
        window = connect_wechat(
            config.wechat_process_name,
            config.wechat_window_title,
        )
        parsed = parse_snapshot(snapshot_window(window, max_nodes=5000))
        if parsed.active_chat != conversation_name:
            raise SendError(
                f"Active chat changed while sending: expected {conversation_name!r}, "
                f"found {parsed.active_chat!r}.",
                reason="active_chat_changed",
            )
        if _contains_recent_outgoing(parsed, text):
            return
        time.sleep(0.2)

    raise SendError(
        "The reply was submitted, but could not be verified in the chat. "
        "Check WeChat before retrying."
    )
