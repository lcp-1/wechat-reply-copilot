from __future__ import annotations

import json

from .config import AppConfig
from .llm import ChatMessage, LlmError, chat_completion
from .storage import list_style_samples, save_style_profile

STYLE_SAMPLE_LIMIT = 300


class StyleProfileError(RuntimeError):
    """Raised when a style profile cannot be generated."""


def build_style_profile(
    config: AppConfig,
    *,
    scope: str,
    conversation_name: str | None = None,
) -> dict[str, object]:
    if scope not in {"global", "conversation"}:
        raise StyleProfileError(f"Unsupported style scope: {scope}")
    if scope == "conversation" and not conversation_name:
        raise StyleProfileError("A conversation name is required for conversation scope.")

    samples = list_style_samples(
        config.database_path,
        conversation_name=conversation_name if scope == "conversation" else None,
        limit=STYLE_SAMPLE_LIMIT,
    )
    minimum_samples = 5 if scope == "global" else 3
    if len(samples) < minimum_samples:
        raise StyleProfileError(
            f"Not enough outgoing samples: {len(samples)} found, {minimum_samples} required."
        )

    prompt = _style_prompt(samples, scope=scope, conversation_name=conversation_name)
    try:
        response = chat_completion(
            config,
            [
                ChatMessage(
                    role="system",
                    content=(
                        "You analyze a person's writing style for a reply assistant. "
                        "Return only valid JSON. Do not infer sensitive personal facts. "
                        "Describe observable language habits, not identity."
                    ),
                ),
                ChatMessage(role="user", content=prompt),
            ],
            temperature=0.2,
        )
    except LlmError as exc:
        raise StyleProfileError(str(exc)) from exc

    profile = _parse_json_object(response)
    summary = str(profile.get("summary", "")).strip()
    if not summary:
        raise StyleProfileError("The model response did not include a style summary.")
    habits = profile.get("habits")
    if not isinstance(habits, dict):
        habits = {}

    save_style_profile(
        config.database_path,
        scope=scope,
        conversation_name=conversation_name,
        summary=summary,
        habits_json=json.dumps(habits, ensure_ascii=False),
        sample_count=len(samples),
    )
    return {
        "scope": scope,
        "conversation": conversation_name,
        "summary": summary,
        "habits": habits,
        "sample_count": len(samples),
    }


def _style_prompt(
    samples: list[str],
    *,
    scope: str,
    conversation_name: str | None,
) -> str:
    label = conversation_name if scope == "conversation" else "global"
    sample_text = "\n".join(f"{index + 1}. {sample}" for index, sample in enumerate(samples))
    return f"""\
Analyze the person's outgoing WeChat messages for style scope: {label}.

Return JSON with this shape:
{{
  "summary": "short direct style summary",
  "habits": {{
    "sentence_length": "...",
    "tone": "...",
    "punctuation": "...",
    "emoji_usage": "...",
    "common_phrases": ["..."],
    "response_patterns": ["..."],
    "avoid": ["..."]
  }}
}}

Only describe observable writing habits. Keep the summary compact.

Messages:
{sample_text}
"""


def _parse_json_object(text: str) -> dict:
    cleaned = text.strip()
    if cleaned.startswith("```"):
        lines = cleaned.splitlines()
        if lines and lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        cleaned = "\n".join(lines).strip()

    try:
        parsed = json.loads(cleaned)
    except json.JSONDecodeError as exc:
        start = cleaned.find("{")
        end = cleaned.rfind("}")
        if start < 0 or end <= start:
            raise StyleProfileError(f"Model did not return valid JSON: {exc}") from exc
        try:
            parsed = json.loads(cleaned[start : end + 1])
        except json.JSONDecodeError as second_exc:
            raise StyleProfileError(
                f"Model did not return valid JSON: {second_exc}"
            ) from second_exc
    if not isinstance(parsed, dict):
        raise StyleProfileError("Model returned JSON that is not an object.")
    return parsed
