from __future__ import annotations

import json

from .config import AppConfig
from .llm import ChatMessage, LlmError, chat_completion
from .storage import current_user, latest_conversation, load_style_profile, recent_messages
from .wechat_text import normalize_wechat_emoji

CONTEXT_MESSAGE_LIMIT = 12


class DraftError(RuntimeError):
    """Raised when draft replies cannot be generated."""


def generate_drafts(
    config: AppConfig,
    *,
    conversation_name: str | None = None,
    count: int = 3,
    messages: list[dict[str, str | None]] | None = None,
) -> dict[str, object]:
    conversation = conversation_name or latest_conversation(config.database_path)
    if not conversation:
        raise DraftError("No synced conversation is available. Run parse and sync first.")

    if messages is None:
        messages = recent_messages(
            config.database_path,
            conversation_name=conversation,
            limit=30,
        )
    if not messages:
        raise DraftError(f"No stored messages for conversation: {conversation}")

    user_name = current_user(config.database_path) or "the user"
    context_messages, pending_messages = _build_reply_context(
        messages,
        current_user=user_name,
        context_limit=CONTEXT_MESSAGE_LIMIT,
    )
    if not pending_messages:
        raise DraftError(
            "The most recent visible message is not an incoming message. "
            "There is no pending reply to draft."
        )
    target_message = pending_messages[-1]

    global_profile = load_style_profile(config.database_path, scope="global")
    conversation_profile = load_style_profile(
        config.database_path,
        scope="conversation",
        conversation_name=conversation,
    )
    style_sources = {
        "context": "current_chat" if messages is not None else "database",
        "global_profile": global_profile is not None,
        "conversation_profile": conversation_profile is not None,
    }
    prompt = _draft_prompt(
        user_name=user_name,
        conversation_name=conversation,
        context_messages=context_messages,
        pending_messages=pending_messages,
        global_profile=global_profile,
        conversation_profile=conversation_profile,
        count=count,
    )

    try:
        response = chat_completion(
            config,
            [
                ChatMessage(
                    role="system",
                    content=(
                        "You write short WeChat messages as a real person, not as an AI assistant. "
                        "Match the user's voice and conversational rhythm. "
                        "Do not invent facts, availability, plans, prices, or commitments. "
                        "If the answer is uncertain, prefer a short clarifying question. "
                        "Return valid JSON only."
                    ),
                ),
                ChatMessage(role="user", content=prompt),
            ],
            temperature=0.6,
        )
    except LlmError as exc:
        raise DraftError(str(exc)) from exc

    drafts = _parse_drafts(response)
    if not drafts:
        raise DraftError("The model returned no usable draft replies.")
    return {
        "conversation": conversation,
        "current_user": user_name,
        "target_message": target_message["content"],
        "context_message_count": len(context_messages),
        "pending_message_count": len(pending_messages),
        "pending_messages": pending_messages,
        "style_sources": style_sources,
        "drafts": drafts,
    }


def _draft_prompt(
    *,
    user_name: str,
    conversation_name: str,
    context_messages: list[dict[str, str | None]],
    pending_messages: list[dict[str, str | None]],
    global_profile: dict[str, object] | None,
    conversation_profile: dict[str, object] | None,
    count: int,
) -> str:
    return f"""\
Write {count} candidate replies for {user_name} to send to {conversation_name}.

Rules:
- Treat all messages under "Pending messages to answer" as one unfinished turn.
- Read every pending message together and address each question, request, or
  relevant point. Do not ignore earlier pending messages because they are not last.
- Default to exactly one WeChat message per candidate. One message is the expected
  result for most replies.
- Only use multiple bubbles as an exception, when there are clearly separate
  actionable questions that cannot be answered naturally in one short message.
- Never map each incoming message to one outgoing bubble. Several incoming
  messages often form one thought and should be answered together.
- Do not split acknowledgements, short reactions, or one simple answer into
  separate bubbles. If in doubt, use one message.
- Use "Recent context" only to resolve references and understand the pending
  messages. Do not reply to completed topics from the context.
- Match the user's natural Mandarin WeChat style.
- Prefer natural, slightly incomplete chat phrasing over complete formal sentences.
- Do not overuse empathy, polite fillers, or explain obvious context.
- Use standard Unicode emoji characters when appropriate. Never write bracket
  emoji codes such as [捂脸]; use emoji only when they fit the user's style and
  avoid overusing them.
- Keep each bubble short and natural, usually under about 30 Chinese characters
  unless the pending messages clearly require more detail.
- Each candidate should have a distinct tone or intent.
- Sound like a real person chatting: avoid assistant phrasing, customer-service
  tone, formal summaries, headings, numbered lists, and phrases such as
  "首先", "其次", "总之", or "希望对你有所帮助" unless they match the user's style.
- Do not add facts or commitments that are not supported by the conversation.
- Do not mention that an AI wrote the reply.

Return JSON:
{{
  "drafts": [
    {{
      "label": "short label",
      "messages": ["first short message", "optional follow-up"],
      "reason": "brief reason"
    }}
  ]
}}

Global style profile:
{json.dumps(global_profile, ensure_ascii=False)}

Conversation style profile:
{json.dumps(conversation_profile, ensure_ascii=False)}

Recent context:
{json.dumps(context_messages, ensure_ascii=False)}

Pending messages to answer:
{json.dumps(pending_messages, ensure_ascii=False)}
"""


def _build_reply_context(
    messages: list[dict[str, str | None]],
    *,
    current_user: str | None = None,
    context_limit: int = CONTEXT_MESSAGE_LIMIT,
) -> tuple[list[dict[str, str | None]], list[dict[str, str | None]]]:
    normalized = _normalize_messages(messages, current_user=current_user)
    if not normalized or normalized[-1]["direction"] != "incoming":
        return [], []

    last_outgoing_index = next(
        (
            index
            for index in range(len(normalized) - 1, -1, -1)
            if normalized[index]["direction"] == "outgoing"
        ),
        None,
    )
    pending_start = 0 if last_outgoing_index is None else last_outgoing_index + 1
    pending_messages = normalized[pending_start:]
    if not pending_messages:
        return [], []

    context_start = max(0, pending_start - max(0, context_limit))
    context_messages = normalized[context_start:pending_start]
    return context_messages, pending_messages


def _normalize_messages(
    messages: list[dict[str, str | None]],
    *,
    current_user: str | None,
) -> list[dict[str, str | None]]:
    normalized: list[dict[str, str | None]] = []
    for message in messages:
        content = str(message.get("content", "")).strip()
        if not content:
            continue

        sender = str(message.get("sender") or "").strip() or None
        direction = str(message.get("direction") or "").strip()
        if direction == "unknown" and sender and sender != current_user:
            direction = "incoming"
        normalized.append(
            {
                "sender": sender,
                "direction": direction,
                "content": content,
            }
        )
    return normalized


def _parse_drafts(response: str) -> list[dict[str, object]]:
    cleaned = response.strip()
    if cleaned.startswith("```"):
        lines = cleaned.splitlines()
        if lines and lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        cleaned = "\n".join(lines).strip()

    try:
        data = json.loads(cleaned)
    except json.JSONDecodeError as exc:
        raise DraftError(f"Model did not return valid JSON: {exc}") from exc

    items = data.get("drafts") if isinstance(data, dict) else data
    if not isinstance(items, list):
        raise DraftError("Model response did not contain a drafts list.")

    drafts: list[dict[str, object]] = []
    for item in items:
        if not isinstance(item, dict):
            continue
        messages = _parse_plan_messages(item)
        if not messages:
            continue
        drafts.append(
            {
                "label": str(item.get("label", "")).strip() or "reply",
                "messages": messages,
                "reason": str(item.get("reason", "")).strip(),
            }
        )
    return drafts


def _parse_plan_messages(item: dict[str, object]) -> list[str]:
    raw_messages = item.get("messages")
    candidates = raw_messages if isinstance(raw_messages, list) else [item.get("text", "")]

    messages: list[str] = []
    for candidate in candidates:
        for line in str(candidate or "").splitlines():
            normalized = normalize_wechat_emoji(line.strip())
            if normalized:
                messages.append(normalized)
    return _merge_short_bubbles(messages[:3])


def _merge_short_bubbles(messages: list[str]) -> list[str]:
    if len(messages) <= 1 or sum(len(message) for message in messages) > 60:
        return messages

    final_punctuation = (
        messages[-1][-1] if messages[-1][-1] in "。！？!?；;，," else ""
    )
    parts = [message.rstrip("。！？!?；;，,") for message in messages]
    return ["，".join(parts) + final_punctuation]


def reply_plan_messages(plan: dict[str, object]) -> list[str]:
    raw_messages = plan.get("messages")
    if isinstance(raw_messages, list):
        messages = [
            str(message).strip()
            for message in raw_messages
            if str(message).strip()
        ]
        if messages:
            return messages

    text = str(plan.get("text") or "").strip()
    if text:
        return [line.strip() for line in text.splitlines() if line.strip()]
    raise DraftError("The reply plan does not contain any messages.")
