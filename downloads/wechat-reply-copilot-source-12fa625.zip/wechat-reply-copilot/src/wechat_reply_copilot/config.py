from __future__ import annotations

import os
import tomllib
from dataclasses import asdict, dataclass
from pathlib import Path

import tomli_w

PROJECT_ROOT = Path(__file__).resolve().parents[2]


def _safe_api_key_env(value: object) -> str:
    candidate = str(value).strip()
    if not candidate or candidate.startswith("sk-") or len(candidate) > 128 or " " in candidate:
        return ProviderConfig.api_key_env
    return candidate


@dataclass(frozen=True)
class ProviderConfig:
    name: str = "deepseek"
    base_url: str = "https://api.deepseek.com"
    model: str = "deepseek-flash"
    api_key_env: str = "DEEPSEEK_API_KEY"
    keyring_service: str = "WeChatReplyCopilot"
    keyring_username: str = "deepseek"
    timeout_seconds: float = 60.0


@dataclass(frozen=True)
class AppConfig:
    provider: ProviderConfig
    database_path: Path
    wechat_process_name: str = "Weixin.exe"
    wechat_window_title: str = ""


def app_data_dir() -> Path:
    root = os.environ.get("LOCALAPPDATA") or str(Path.home())
    return Path(root) / "WeChatReplyCopilot"


def default_config_path() -> Path:
    override = os.environ.get("WRC_CONFIG_PATH", "").strip()
    if override:
        return Path(override).expanduser()
    project_config = PROJECT_ROOT / "config.local.toml"
    if (PROJECT_ROOT / "pyproject.toml").exists():
        return project_config
    root = os.environ.get("APPDATA") or str(Path.home())
    return Path(root) / "WeChatReplyCopilot" / "config.toml"


def load_config(path: Path | None = None) -> AppConfig:
    config_path = path or default_config_path()
    raw: dict = {}
    if config_path.exists():
        with config_path.open("rb") as handle:
            raw = tomllib.load(handle)

    provider_raw = raw.get("provider", {})
    provider_defaults = ProviderConfig()
    provider = ProviderConfig(
        name=str(provider_raw.get("name", provider_defaults.name)),
        base_url=str(provider_raw.get("base_url", provider_defaults.base_url)).rstrip("/"),
        model=str(provider_raw.get("model", provider_defaults.model)),
        api_key_env=_safe_api_key_env(
            provider_raw.get("api_key_env", provider_defaults.api_key_env)
        ),
        keyring_service=str(provider_raw.get("keyring_service", provider_defaults.keyring_service)),
        keyring_username=str(
            provider_raw.get("keyring_username", provider_defaults.keyring_username)
        ),
        timeout_seconds=float(
            provider_raw.get("timeout_seconds", provider_defaults.timeout_seconds)
        ),
    )

    database_raw = raw.get("database", {})
    configured_path = database_raw.get("path")
    database_path = (
        Path(configured_path).expanduser() if configured_path else app_data_dir() / "data.sqlite3"
    )

    wechat_raw = raw.get("wechat", {})
    return AppConfig(
        provider=provider,
        database_path=database_path,
        wechat_process_name=str(wechat_raw.get("process_name", AppConfig.wechat_process_name)),
        wechat_window_title=str(wechat_raw.get("window_title", AppConfig.wechat_window_title)),
    )


def config_data(provider: ProviderConfig) -> dict:
    return {
        "provider": {
            "name": provider.name,
            "base_url": provider.base_url,
            "model": provider.model,
            "api_key_env": provider.api_key_env,
            "keyring_service": provider.keyring_service,
            "keyring_username": provider.keyring_username,
            "timeout_seconds": provider.timeout_seconds,
        },
        "wechat": {
            "process_name": "Weixin.exe",
            "window_title": AppConfig.wechat_window_title,
        },
    }


def render_config(provider: ProviderConfig) -> str:
    return tomli_w.dumps(config_data(provider))


def write_config(path: Path, provider: ProviderConfig) -> None:
    data = config_data(provider)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(tomli_w.dumps(data), encoding="utf-8")


def provider_as_dict(provider: ProviderConfig) -> dict:
    return asdict(provider)
