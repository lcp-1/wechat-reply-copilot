from __future__ import annotations

import hashlib
import json
import sqlite3
from contextlib import closing
from datetime import UTC, datetime
from pathlib import Path

from .parser import ParsedSnapshot

SCHEMA = """
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS conversations (
    id INTEGER PRIMARY KEY,
    platform TEXT NOT NULL DEFAULT 'wechat',
    external_id TEXT,
    display_name TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    UNIQUE(platform, display_name)
);

CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY,
    conversation_id INTEGER NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
    direction TEXT NOT NULL CHECK(direction IN ('incoming', 'outgoing', 'unknown')),
    sender TEXT,
    content TEXT NOT NULL,
    fingerprint TEXT NOT NULL,
    observed_at TEXT NOT NULL,
    sent_at TEXT,
    raw_json TEXT,
    UNIQUE(conversation_id, fingerprint)
);

CREATE TABLE IF NOT EXISTS style_samples (
    id INTEGER PRIMARY KEY,
    conversation_id INTEGER REFERENCES conversations(id) ON DELETE SET NULL,
    scene TEXT,
    content TEXT NOT NULL,
    source_message_id INTEGER REFERENCES messages(id) ON DELETE SET NULL,
    approved_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS global_style_profiles (
    id INTEGER PRIMARY KEY CHECK(id = 1),
    summary TEXT NOT NULL,
    habits_json TEXT NOT NULL,
    sample_count INTEGER NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS conversation_style_profiles (
    conversation_id INTEGER PRIMARY KEY REFERENCES conversations(id) ON DELETE CASCADE,
    summary TEXT NOT NULL,
    habits_json TEXT NOT NULL,
    sample_count INTEGER NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS metadata (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_style_samples_source
ON style_samples(source_message_id)
WHERE source_message_id IS NOT NULL;
"""


def initialize_database(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with closing(sqlite3.connect(path)) as connection:
        connection.executescript(SCHEMA)
        connection.execute(
            "INSERT OR REPLACE INTO metadata(key, value) VALUES (?, ?)",
            ("schema_version", "2"),
        )
        connection.commit()


def database_summary(path: Path) -> dict[str, object]:
    if not path.exists():
        return {"exists": False, "path": str(path), "tables": {}}

    with closing(sqlite3.connect(path)) as connection:
        tables = [
            row[0]
            for row in connection.execute(
                "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
            )
        ]
        counts = {}
        for table in tables:
            if table.startswith("sqlite_"):
                continue
            counts[table] = connection.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]

    return {
        "exists": True,
        "path": str(path),
        "tables": counts,
        "checked_at": datetime.now(UTC).isoformat(),
    }


def sync_parsed_snapshot(path: Path, parsed: ParsedSnapshot) -> dict[str, int | str]:
    initialize_database(path)
    observed_at = datetime.now(UTC).isoformat()
    conversation_name = parsed.active_chat or "unknown"

    with closing(sqlite3.connect(path)) as connection:
        connection.execute("PRAGMA foreign_keys = ON")
        if parsed.current_user:
            connection.execute(
                "INSERT OR REPLACE INTO metadata(key, value) VALUES ('current_user', ?)",
                (parsed.current_user,),
            )
        conversation_id = _upsert_conversation(
            connection,
            display_name=conversation_name,
            observed_at=observed_at,
        )
        inserted_messages = 0
        inserted_style_samples = 0

        for message in parsed.messages:
            fingerprint = _message_fingerprint(
                conversation_id=conversation_id,
                sender=message.sender,
                direction=message.direction,
                content=message.content,
            )
            cursor = connection.execute(
                """
                INSERT OR IGNORE INTO messages(
                    conversation_id,
                    direction,
                    sender,
                    content,
                    fingerprint,
                    observed_at,
                    raw_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    conversation_id,
                    message.direction,
                    message.sender,
                    message.content,
                    fingerprint,
                    observed_at,
                    json.dumps(
                        {
                            "sender": message.sender,
                            "direction": message.direction,
                            "content": message.content,
                        },
                        ensure_ascii=False,
                    ),
                ),
            )
            if cursor.rowcount == 0:
                continue

            inserted_messages += 1
            if message.direction != "outgoing":
                continue

            message_id = cursor.lastrowid
            style_cursor = connection.execute(
                """
                INSERT OR IGNORE INTO style_samples(
                    conversation_id,
                    scene,
                    content,
                    source_message_id,
                    approved_at
                ) VALUES (?, ?, ?, ?, ?)
                """,
                (
                    conversation_id,
                    None,
                    message.content,
                    message_id,
                    observed_at,
                ),
            )
            inserted_style_samples += style_cursor.rowcount

        connection.commit()

    return {
        "conversation": conversation_name,
        "inserted_messages": inserted_messages,
        "inserted_style_samples": inserted_style_samples,
    }


def style_stats(path: Path, conversation_name: str | None = None) -> dict[str, object]:
    initialize_database(path)
    with closing(sqlite3.connect(path)) as connection:
        global_samples = connection.execute("SELECT COUNT(*) FROM style_samples").fetchone()[0]
        conversation_stats = [
            {
                "conversation": row[0],
                "messages": row[1],
                "incoming_messages": row[2],
                "outgoing_messages": row[3],
                "unknown_messages": row[4],
                "samples": row[5],
                "average_characters": round(row[6] or 0, 1),
            }
            for row in connection.execute(
                """
                SELECT
                    c.display_name,
                    COUNT(DISTINCT m.id),
                    COUNT(DISTINCT CASE WHEN m.direction = 'incoming' THEN m.id END),
                    COUNT(DISTINCT CASE WHEN m.direction = 'outgoing' THEN m.id END),
                    COUNT(DISTINCT CASE WHEN m.direction = 'unknown' THEN m.id END),
                    COUNT(DISTINCT s.id),
                    AVG(CASE WHEN m.direction = 'outgoing' THEN LENGTH(m.content) END)
                FROM conversations c
                LEFT JOIN messages m ON m.conversation_id = c.id
                LEFT JOIN style_samples s ON s.conversation_id = c.id
                GROUP BY c.id, c.display_name
                ORDER BY COUNT(DISTINCT m.id) DESC, c.display_name
                """
            )
        ]

        selected = None
        if conversation_name:
            selected = next(
                (item for item in conversation_stats if item["conversation"] == conversation_name),
                None,
            )

    return {
        "global_samples": global_samples,
        "conversation_stats": conversation_stats,
        "selected_conversation": selected,
    }


def list_style_samples(
    path: Path,
    *,
    conversation_name: str | None = None,
    limit: int = 200,
) -> list[str]:
    initialize_database(path)
    params: list[object] = []
    where = ""
    if conversation_name:
        where = "WHERE c.display_name = ?"
        params.append(conversation_name)
    params.append(limit)

    with closing(sqlite3.connect(path)) as connection:
        return [
            row[0]
            for row in connection.execute(
                f"""
                SELECT s.content
                FROM style_samples s
                LEFT JOIN conversations c ON c.id = s.conversation_id
                {where}
                ORDER BY s.id DESC
                LIMIT ?
                """,
                params,
            )
        ]


def save_style_profile(
    path: Path,
    *,
    scope: str,
    summary: str,
    habits_json: str,
    sample_count: int,
    conversation_name: str | None = None,
) -> None:
    initialize_database(path)
    updated_at = datetime.now(UTC).isoformat()
    with closing(sqlite3.connect(path)) as connection:
        connection.execute("PRAGMA foreign_keys = ON")
        if scope == "global":
            connection.execute(
                """
                INSERT INTO global_style_profiles(
                    id,
                    summary,
                    habits_json,
                    sample_count,
                    updated_at
                ) VALUES (1, ?, ?, ?, ?)
                ON CONFLICT(id)
                DO UPDATE SET
                    summary = excluded.summary,
                    habits_json = excluded.habits_json,
                    sample_count = excluded.sample_count,
                    updated_at = excluded.updated_at
                """,
                (summary, habits_json, sample_count, updated_at),
            )
        elif scope == "conversation":
            if not conversation_name:
                raise ValueError("conversation_name is required for conversation scope.")
            conversation_id = _find_conversation_id(connection, conversation_name)
            if conversation_id is None:
                raise ValueError(f"Conversation not found: {conversation_name}")
            connection.execute(
                """
                INSERT INTO conversation_style_profiles(
                    conversation_id,
                    summary,
                    habits_json,
                    sample_count,
                    updated_at
                ) VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(conversation_id)
                DO UPDATE SET
                    summary = excluded.summary,
                    habits_json = excluded.habits_json,
                    sample_count = excluded.sample_count,
                    updated_at = excluded.updated_at
                """,
                (conversation_id, summary, habits_json, sample_count, updated_at),
            )
        else:
            raise ValueError(f"Unsupported style profile scope: {scope}")
        connection.commit()


def load_style_profile(
    path: Path,
    *,
    scope: str,
    conversation_name: str | None = None,
) -> dict[str, object] | None:
    initialize_database(path)
    with closing(sqlite3.connect(path)) as connection:
        if scope == "global":
            row = connection.execute(
                """
                SELECT summary, habits_json, sample_count, updated_at
                FROM global_style_profiles
                WHERE id = 1
                """
            ).fetchone()
        elif scope == "conversation":
            if not conversation_name:
                raise ValueError("conversation_name is required for conversation scope.")
            row = connection.execute(
                """
                SELECT p.summary, p.habits_json, p.sample_count, p.updated_at
                FROM conversation_style_profiles p
                JOIN conversations c ON c.id = p.conversation_id
                WHERE c.display_name = ?
                """,
                (conversation_name,),
            ).fetchone()
        else:
            raise ValueError(f"Unsupported style profile scope: {scope}")

    if row is None:
        return None
    return {
        "scope": scope,
        "conversation": conversation_name,
        "summary": row[0],
        "habits": json.loads(row[1]),
        "sample_count": row[2],
        "updated_at": row[3],
    }


def recent_messages(
    path: Path,
    *,
    conversation_name: str,
    limit: int = 30,
) -> list[dict[str, str | None]]:
    initialize_database(path)
    with closing(sqlite3.connect(path)) as connection:
        rows = list(
            connection.execute(
                """
                SELECT m.sender, m.direction, m.content
                FROM messages m
                JOIN conversations c ON c.id = m.conversation_id
                WHERE c.display_name = ?
                ORDER BY m.id DESC
                LIMIT ?
                """,
                (conversation_name, limit),
            )
        )
    return [
        {
            "sender": row[0],
            "direction": row[1],
            "content": row[2],
        }
        for row in reversed(rows)
    ]


def current_user(path: Path) -> str | None:
    initialize_database(path)
    with closing(sqlite3.connect(path)) as connection:
        row = connection.execute("SELECT value FROM metadata WHERE key = 'current_user'").fetchone()
    return str(row[0]) if row else None


def latest_conversation(path: Path) -> str | None:
    initialize_database(path)
    with closing(sqlite3.connect(path)) as connection:
        row = connection.execute(
            """
            SELECT c.display_name
            FROM conversations c
            JOIN messages m ON m.conversation_id = c.id
            GROUP BY c.id, c.display_name, c.updated_at
            ORDER BY c.updated_at DESC, MAX(m.id) DESC
            LIMIT 1
            """
        ).fetchone()
    return str(row[0]) if row else None


def _upsert_conversation(
    connection: sqlite3.Connection,
    *,
    display_name: str,
    observed_at: str,
) -> int:
    connection.execute(
        """
        INSERT INTO conversations(
            platform,
            external_id,
            display_name,
            created_at,
            updated_at
        ) VALUES ('wechat', NULL, ?, ?, ?)
        ON CONFLICT(platform, display_name)
        DO UPDATE SET updated_at = excluded.updated_at
        """,
        (display_name, observed_at, observed_at),
    )
    row = connection.execute(
        """
        SELECT id
        FROM conversations
        WHERE platform = 'wechat' AND display_name = ?
        """,
        (display_name,),
    ).fetchone()
    if row is None:
        raise RuntimeError("Failed to create conversation row.")
    return int(row[0])


def _find_conversation_id(
    connection: sqlite3.Connection,
    display_name: str,
) -> int | None:
    row = connection.execute(
        """
        SELECT id
        FROM conversations
        WHERE platform = 'wechat' AND display_name = ?
        """,
        (display_name,),
    ).fetchone()
    return int(row[0]) if row else None


def _message_fingerprint(
    *,
    conversation_id: int,
    sender: str | None,
    direction: str,
    content: str,
) -> str:
    payload = "\x1f".join(
        [
            str(conversation_id),
            direction,
            sender or "",
            content,
        ]
    )
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()
